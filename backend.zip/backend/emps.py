from flask import jsonify
from flask import Blueprint
from util import strategy_helper

api_emp = Blueprint('api_emp', __name__)


@api_emp.route("/emp/<id>", methods=['GET'])
def getEmp(id):
    data = strategy_helper.getEmps(id)
    # [{"name": "vinod", "id": 1}, {"name": "pri", "id": 2}]
    return jsonify(data)


@api_emp.route("/emp/<id>", methods=['DELETE'])
def deleteEmp(id):
    data = [{"firstname": "Vinod","lastname": "Nayal", "id": 1},
            {"name": "Priyanka","lastname": "Jalal", "id": 2},
            {"name": "Garvit","lastname": "Nayal", "id": 3}]
    return jsonify(data)


@api_emp.route("/emp", methods=['GET'])
def getEmps():
    data = [{"firstname": "Vinod","lastname": "Nayal", "id": 1},
            {"firstname": "Priyanka","lastname": "Jalal", "id": 2},
            {"firstname": "Garvit","lastname": "Nayal", "id": 3}]
    return jsonify(data)
