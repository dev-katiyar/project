import ConfigParser
class MyConfig:
    mongodb_host = "13.58.218.147"  # "172.31.2.243"  # "13.58.218.147" #"18.188.218.82"
    mongodb_port = 27017
    mysqldb_host = "18.188.218.82"  # "13.58.218.147"  # "13.58.218.147"  # "13.58.218.147" # "172.31.2.243"  # "13.58.218.147"  "172.31.2.243"   18.188.218.82
    mysqldb_port = 3306
    mysqldb_user = "riapro"
    mysqldb_passwd = "Riapro123$"
    mysqldb_db = "riapro"
    email = "support@riapro.net"
    email_password = "P0o9i8u&"
    IEX_API_KEY = "pk_8a112308f6444aaeb6cec64ccdf37108"
    stripe_private_key = "sk_live_0gBo7EUkoGPx2NdF0J6GDa6Z"  # "sk_test_Yel3r9PsW3cAOJJdyLSPbAKh"
    test_stripe_private_key = "sk_test_Yel3r9PsW3cAOJJdyLSPbAKh"
    # annual , monthly , monthly tpa ,tpa annual
    plans = {"2": "plan_Dig3CEENa6YiEA", "1": "plan_DCswPGER9UqWTx",
             "4": "plan_HJW6zclDN4iwNp", "5": "plan_HJVt7Z3smn2rYI"}
    test_plans = {"1": "plan_DlR2TRQILlHkiR", "4": "price_1GuOWIBMoAW2pb450trzW2ft"}
    admin_users_emails = "priyankajalaldit@gmail.com,mplebow@720global.com,lance@myclarityfinancial.com,support@riapro.net"
    RAPID_KEY = "5F4HFBtPz48BEb99fSdfr4pPCMPfsQv25os50CmA"
    RAPID_BASE_API = "https://yfapi.net"