from flask import make_response, jsonify
import jwt
import datetime
import dbutil
import stripe_payment


def post(post_data):
    # get the post data

    try:
        username = post_data.get('username')
        password = post_data.get('password')
        auth_token = None

        loggedInUser = dbutil.getUserDetails(username, password)
        if (loggedInUser):
            if (loggedInUser['isPaid'] == 1):
                auth_token = encode_auth_token(loggedInUser)
            else:
                isStillActive = stripe_payment.isUserActive(loggedInUser["userId"])
                if isStillActive == 1:
                    auth_token = encode_auth_token(loggedInUser)
                else:
                    responseObject = {
                        'status': 'fail',
                        'type': 'TRIAL_ENDED',
                        'message': 'Your trial period has ended. Please register with Credit Card for live account.',
                        'username': username,
                        'userId': loggedInUser['userId'],
                    }
                    print(responseObject)
                    return make_response(jsonify(responseObject)), 200
        else:
            responseObject = {
                'status': 'fail',
                'message': 'Email or Password not correct.'
            }
            return make_response(jsonify(responseObject)), 403

        if auth_token:
            responseObject = {
                'status': 'success',
                'message': 'Successfully logged in.',
                'auth_token': auth_token.decode(),
                'username': username,
                'userId': loggedInUser['userId'],
                'firstName': loggedInUser['firstName'],
                'lastName': loggedInUser['lastName'],
            }
            return make_response(jsonify(responseObject)), 200
        else:
            responseObject = {
                'status': 'fail',
                'message': 'User does not exist.'
            }
        return make_response(jsonify(responseObject)), 403

    except Exception as e:
        print(e)
        responseObject = {
            'status': 'fail',
            'message': 'Try again'
        }
        return make_response(jsonify(responseObject)), 500


def encode_auth_token(loggedInUser):
    """
    Generates the Auth Token
    :return: string
    """
    try:
        payload = {
            'exp': datetime.datetime.utcnow() + datetime.timedelta(days=15, seconds=5),
            'iat': datetime.datetime.utcnow(),
            'sub': loggedInUser
        }
        return jwt.encode(
            payload,
            'SECRET_KEY',
            algorithm='HS256'
        )
    except Exception as e:
        return e


def decode_auth_token(auth_token):
    """
    Validates the auth token
    :param auth_token:
    :return: integer|string
    """
    try:
        payload = jwt.decode(auth_token, 'SECRET_KEY')
        loggedInUser = payload['sub']
        if 'isPaid' not in payload["sub"]:
            return 'Signature expired. Please log in again.'
        #isPaid = payload["sub"]["isPaid"]
        # if isPaid != 1:
        #     return 'Please upgrade your account.'
        return loggedInUser
    except jwt.ExpiredSignatureError:
        return 'Signature expired. Please log in again.'
    except jwt.InvalidTokenError:
        return 'Invalid token. Please log in again.'

def getUserId(request):
    userId = 0
    token = checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
    return userId

def checkToken(req):
    # get the auth token
    auth_header = req.headers.get('Authorization')
    if auth_header:
        try:
            auth_token = auth_header.split(" ")[1]
        except IndexError:
            responseObject = {
                'status': 'fail',
                'message': 'Bearer token malformed.'
            }
            return responseObject
    else:
        auth_token = ''
    if auth_token:
        resp = decode_auth_token(auth_token)
        if not isinstance(resp, str):
            responseObject = {
                'status': 'success',
                'data': {
                    'user_id': resp['userId'],
                    'email': resp['emailaddress'],
                    'isPaid': resp['isPaid'],
                    'registered_on': resp
                }
            }
            return responseObject
        responseObject = {
            'status': 'fail',
            'message': resp
        }
        return responseObject
    else:
        responseObject = {
            'status': 'fail',
            'message': 'Provide a valid auth token.'
        }
        return responseObject
