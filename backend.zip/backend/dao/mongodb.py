import pymongo
from MyConfig import MyConfig as cfg

def getDbConnection():
    con_mongo = pymongo.MongoClient(cfg.mongodb_host, port=cfg.mongodb_port)
    return con_mongo

def get_data(collectionName, condition):
    try:
        con_mongo = getDbConnection()
        db = con_mongo.chartlab
        dataCursor = db[collectionName].find(condition)
        filters = []
        for item in dataCursor:
            del item['_id']
            filters.append(item)
        con_mongo.close()
        return filters
    except Exception, ex:
        print ex
    finally:
        con_mongo.close()


def save_multiple(collectionName, rows):
    try:
        con_mongo = getDbConnection()
        db = con_mongo.chartlab
        db[collectionName].remove({})
        db[collectionName].insert_many(rows)
    except Exception, ex:
        print ex
    finally:
        con_mongo.close()


def save_one_row(collectionName, data, unique_field="id"):
    try:
        con_mongo = getDbConnection()
        db = con_mongo.chartlab
        if unique_field in data:
            db[collectionName].remove({unique_field: data[unique_field]})
        db[collectionName].save(data)
    except Exception, ex:
        print ex
    finally:
        con_mongo.close()

def delete(collectionName, id):
    try:
        con_mongo = getDbConnection()
        db = con_mongo.chartlab
        db[collectionName].remove({"id": id})
    except Exception, ex:
        print ex
    finally:
        con_mongo.close()


