import sys
 
sys.path.insert(0,"C:/Program Files (x86)/Ampps/www/website-latest/backend")
 
from index import app as application