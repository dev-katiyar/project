import dbutil


def getEmps(id):
    sql_getUsers = "select * from users where emailAddress like '%{}%'".format(id)
    print sql_getUsers
    return dbutil.getDataTable(sql_getUsers)
