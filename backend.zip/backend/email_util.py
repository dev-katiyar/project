import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from MyConfig import MyConfig as cfg


def sendEmail(subject, body, to_user):
  to_user_list = to_user.split(",")
  from_user = cfg.email
  pwd = cfg.email_password
  smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
  smtpserver.starttls()
  smtpserver.login(from_user, pwd)
  print "Sending email to {}".format(to_user)
  msg = MIMEMultipart()
  msg['From'] = from_user
  msg['Subject'] = subject
  email_content = body
  msg.attach(MIMEText(email_content, 'html'))
  smtpserver.sendmail(from_user, to_user_list, msg.as_string())
  smtpserver.close()
