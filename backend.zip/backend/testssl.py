import os, ssl
import urllib2,json
import os, ssl
if (not os.environ.get('PYTHONHTTPSVERIFY', '') and
        getattr(ssl, '_create_unverified_context', None)):
    ssl._create_default_https_context = ssl._create_unverified_context

url ="https://cloud.iexapis.com/stable/stock/AAPL/intraday-prices?token=pk_8a112308f6444aaeb6cec64ccdf37108&chartInterval=2"
data = urllib2.urlopen(url, timeout=30).read()
feed_data = json.loads(data)
print feed_data
