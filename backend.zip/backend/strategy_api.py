from flask import Blueprint, request, jsonify
import json
from dateutil import parser, relativedelta
import datetimeutil
import numpy as np
import dbutil
from util import strategy_util

api_strategy = Blueprint('api_strategy', __name__)


# API to take care of RIA Pro Strategy
@api_strategy.route('/strategy/riapro', methods=['POST', 'GET'])
def process_riapro_strategy():
    try:
        riapro_strategy_inputs = json.loads(request.data)

        # COMMON INPUTS
        model_inputs = riapro_strategy_inputs["model_inputs"]
        symbol = model_inputs["symbol"]
        start_date = parser.parse(model_inputs["start_date"]).strftime("%Y-%m-%d")
        end_date = parser.parse(model_inputs["end_date"]).strftime("%Y-%m-%d")
        start_date = datetimeutil.getdatefromstr(start_date)
        end_date = datetimeutil.getdatefromstr(end_date)
        sample_frequency = model_inputs["sample_frequency"]

        # GET INPUT DF
        df = get_strategy_input_df(symbol, start_date, end_date, sample_frequency)

        # GET OUTPUT DF
        ria_pro_inputs = riapro_strategy_inputs["ria_pro_inputs"]       # ## Strategy specific indicator inputs
        test_period = df.loc[start_date: end_date, "close"].count()  # model_inputs["test_period"] - REMOVE?
        result_df = strategy_util.get_riapro_strategy_output(df, ria_pro_inputs, test_period)

        return dbutil.df_to_json(result_df)
    except Exception as ex:
        return jsonify({"status": "failed", "message": "Problem in running the strategy: {}".format(ex)})


# GETS APPROPRIATE DF BASED ON MODEL INPUTS
def get_strategy_input_df(symbol, start_date, end_date, sample_frequency):
    if sample_frequency == "days":
        df_start_date = start_date + relativedelta.relativedelta(days=-110)  # Min-38 max-70 trade days input periods
        df = dbutil.getsymbol_data(symbol, df_start_date, end_date)
    elif sample_frequency == "weeks":
        df_start_date = start_date + relativedelta.relativedelta(days=-500)  # Min-38 max-70 trade weeks input periods
        df = dbutil.getsymbol_data(symbol, df_start_date, end_date)
        df = get_weekly_df_from_daily_df(df)

    return df


# RESAMPLES DAILY DF FOR WEEKLY DF
def get_weekly_df_from_daily_df(df):
    df_weekly = df.resample('W-MON', label='left', closed='left').agg({
        'actualclose': lambda x: x[-1],
        'close': lambda x: x[-1],
        'high': np.max,
        'low': np.min,
        'open': lambda x: x[0],
        'volume': sum,
        'symbol': lambda x: x[0]})
    return df_weekly
