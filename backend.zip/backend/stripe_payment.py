import stripe
from MyConfig import MyConfig as cfg
import dbutil

stripe.api_key = cfg.stripe_private_key


def create_customer(user):
    customer = stripe.Customer.create(
        email=user["email"],
        source=user["card_id"]
    )
    print customer.id


def get_all_coupouns():
    coupons = stripe.Coupon.list(limit=300)
    # coupons.data[0].name.lower()
    coupons_dict = {}
    for coupon in coupons:
        coupons_dict.update({coupon.name.lower(): coupon.stripe_id})

    return coupons_dict


def modifySubscription(customer_id, newPlan):
    customer = stripe.Customer.retrieve(customer_id)
    subscription_id = customer["subscriptions"]["data"][0]["id"]
    subscription = stripe.Subscription.retrieve(subscription_id)
    print "updating subscription {} details {} new plan {}".format(subscription.id, subscription['items']['data'][0].id,
                                                                   newPlan)
    stripe.Subscription.modify(
        subscription.id,
        cancel_at_period_end=False,
        proration_behavior='create_prorations',
        items=[{
            'id': subscription['items']['data'][0].id,
            'plan': newPlan,
        }]
    )


def create_customer_and_subscription(user):
    coupons = get_all_coupouns()
    coupon = ""
    customer = stripe.Customer.create(
        email=user["email"],
        source=user["card_id"]
    )
    user_coupoun = user["promoCode"].lower()
    if user_coupoun in coupons:
        coupon = coupons[user_coupoun]
    if str(user["subscription"]) == "3":
        oneTimeCharge(user, customer, coupon)
    else:
        plans = cfg.plans
        userPlan = plans[str(user["subscription"])]
        if coupon != "":
            subscription = stripe.Subscription.create(
                customer=customer.id,
                items=[{'plan': userPlan}],
                coupon=coupon,
                trial_period_days=30
            )
        else:
            subscription = stripe.Subscription.create(
                customer=customer.id,
                items=[{'plan': userPlan}],
                trial_period_days=30
            )
    return customer


def createSubscription(customer_id, selectedPlan):
    customer = stripe.Customer.retrieve(customer_id)
    print "For customer_id {} adding subscription {} ".format(customer_id, selectedPlan)
    subscription = stripe.Subscription.create(
        customer=customer.id,
        items=[{'plan': selectedPlan}]
    )


def oneTimeCharge(user, customer, coupon):
    life_time_charge = 299900
    if coupon != "":
        life_time_charge = 249900
        charge = stripe.Charge.create(
            customer=customer.id,
            amount=life_time_charge,
            currency='usd',
            description='Founders Lifetime RIA Pro Plan'
        )
    else:
        charge = stripe.Charge.create(
            customer=customer.id,
            amount=life_time_charge,
            currency='usd',
            description='Founders Lifetime RIA Pro Plan'
        )


def getStripeCustomerId(userId):
    sql = "select stripe_user_id ,emailAddress from users where userid ={}".format(userId)
    stripe_customer_id = dbutil.getOneRow(sql, "stripe_user_id")
    user_email = dbutil.getOneRow(sql, "emailAddress")
    if stripe_customer_id is None or stripe_customer_id == "":
        user_list = stripe.Customer.list(email=user_email)
        if len(user_list) == 1:
            stripr_customer_id = user_list[0].id
    return stripe_customer_id


def cancelSubscription(userId):
    try:
        customer_id = getStripeCustomerId(userId)
        stripe_customer = stripe.Customer.retrieve(customer_id)
        subscription_data_list = stripe_customer['subscriptions']['data']
        print(subscription_data_list)
        for subscription_data in subscription_data_list:
            response = stripe.Subscription.modify(
                subscription_data.id,
                cancel_at_period_end=True
            )
    except Exception, ex:
        print ex
        return None

def redActivateSubscription(userId):
    try:
        customer_id = getStripeCustomerId(userId)
        stripe_customer = stripe.Customer.retrieve(customer_id)
        subscription_data = stripe_customer['subscriptions']['data'][0]

        response = stripe.Subscription.modify(
            subscription_data.id,
            cancel_at_period_end=False
        )
        return response
    except Exception, ex:
        print ex
        return None


def updateCard(userId, newCardToken):
    customer_id = getStripeCustomerId(userId)
    cards = stripe.Customer.list_sources(
        customer_id,
        limit=3,
        object='card'
    )

    # new_card = stripe.Customer.create_source(
    #     customer_id,
    #     source=newCardToken
    # )
    response = stripe.Customer.modify(
        customer_id,
        source=newCardToken
    )
    return response


def isUserActive(userId):
    user_active = 1
    try:
        customer_id = getStripeCustomerId(userId)
        stripe_customer = stripe.Customer.retrieve(customer_id)
        subscription_data = stripe_customer['subscriptions']['data'][0]
        if 'current_period_end' not in subscription_data:
            user_active = 0
        return user_active
    except Exception, ex:
        print ex
        user_active = 0
        return user_active
