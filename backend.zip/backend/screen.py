import json
import dbutil
from dao import mongodb
from flask import Blueprint
from flask import request, make_response, jsonify
import login
import constants

api_screen = Blueprint('api_screen', __name__)

technical_join = "technicals_symbol on technicals_symbol.symbol=list_symbol.symbol"
live_symbol_join = "live_symbol on live_symbol.symbol=list_symbol.symbol"


# returns presets by a userId
def getPresets(userId):
    presets = mongodb.get_data("presets", {"userId": userId})
    return presets


# gets presets for model user
@api_screen.route("/screen/model/preset", methods=['GET'])
def getModelPreset():
    presets = getPresets(constants.MODEL_USER_ID)  # lance userId
    return jsonify(presets)


# get presets for current User
@api_screen.route("/screen/preset", methods=['GET'])
def getUserPreset():
    myUserId = login.getUserId(request)
    presets = getPresets(myUserId)
    return jsonify(presets)


# get presets for current User
@api_screen.route("/screen/preset/<id>", methods=['GET'])
def getUserPresetById(id):
    myUserId = login.getUserId(request)
    presets = mongodb.get_data("presets", {"userId": myUserId, "id": id})
    return jsonify(presets)


@api_screen.route("/screen/model_preset/<id>", methods=['GET'])
def getPresetById(id):
    filterData = mongodb.get_data("presets", {"id": id})
    return jsonify(filterData)


# delete presets
@api_screen.route("/screen/preset", methods=['DELETE'])
def deletePreset():
    id = request.args.get('id')
    mongodb.delete("presets", id)
    return jsonify({"status": "ok", "success": "1", "reason": "Preset Deleted Successfully!", "id": id})


# save presets
@api_screen.route("/screen/preset", methods=['POST'])
def saveUserPreset():
    myUserId = login.getUserId(request)
    post_data = json.loads(request.data)
    name = post_data["name"].strip()
    id = "{}-{}".format(myUserId, name)
    post_data["id"] = id
    post_data["userId"] = myUserId
    # presets = {"userId": myUserId, "name": name, "preSets": post_data, "id": id}
    mongodb.save_one_row("presets", post_data)
    return jsonify({"status": "ok", "success": "1", "reason": "Preset Saved Successfully!", "id": id})


@api_screen.route("/screen/filter", methods=['GET'])
def getScreenFilter():
    filterData = mongodb.get_data("filters", {})
    return jsonify(filterData)


# returns filtered tickers
@api_screen.route("/screen/filter", methods=['POST'])
def getScreenSymbols():
    post_data = json.loads(request.data)
    # print post_data
    values = post_data["values"]
    # print(post_data["values"])
    join_condition = map(lambda x: createJoinCondition(x), values)
    flat_list = [item for sublist in join_condition for item in sublist]

    joinList = list(set(flat_list))
    if technical_join not in joinList:
        joinList.append(technical_join)
    if live_symbol_join not in joinList:
        joinList.append(live_symbol_join)


    where_conditions = filter(lambda row: row != "", map(lambda row: createWhereCondition(row), values))
    where_conditions.append("list_symbol.isactive = 1")
    where_conditions.append("live_symbol.last > 1")
    where_conditions.append("DATEDIFF(now(),live_symbol.time) < 7")
    # where_conditions.append("technicals_symbol is not null")
    where_condition_formatted = ""
    if (len(where_conditions) > 0):
        where_condition_formatted = " and ".join(where_conditions)
        where_condition_formatted = " where {}".format(where_condition_formatted)

    sortBy = ""
    limit = ""

    if ("sortBy" in post_data):
        if post_data["sortBy"].split(" ")[0] != "-1":
            sql = """select field as id ,name,join_column from screen_sort_columns;"""
            sortByFull = post_data["sortBy"]
            sortByVal= sortByFull.split(" ")[0]
            sortColumnsDict = dbutil.getDataDict(sql, "id")
            join_sort_column = sortColumnsDict[sortByVal]['join_column']
            if join_sort_column:
                if join_sort_column not in joinList:
                    joinList.append(join_sort_column)
            sortBy = "order by {}".format(sortByFull)
    if ("limit" in post_data):
        if post_data["limit"] != "-1":
            limit = "limit {}".format(post_data["limit"])
    else:
        limit = "limit 1000"
    formattedJoinCondition = ""
    if (len(joinList) > 0):
        formattedJoinCondition = " join " + " join ".join(joinList)
    sql = """SELECT distinct list_symbol.symbol as symbol FROM list_symbol
		    {}  {} {} {}""".format(formattedJoinCondition, where_condition_formatted, sortBy, limit)
    print(sql)
    symbols = dbutil.getDataArray(sql)
    return jsonify(symbols)


def createWhereCondition(row):
    if row["table"] == "multiple":
        return ""
    else:
        if row["type"] == "slider":
            selected_slider_values = row["selected_slider_values"]
            min = selected_slider_values[0]
            max = selected_slider_values[1]
            field = row["field"]
            return "{} >= {} and {} <= {}".format(field, min, field, max)
        else:
            return row["selected_value"]


def createJoinCondition(row):
    if row["table"] == "multiple":
        joinTableName = row["selected_value"]
        joinCondition = "{} on {}.symbol = list_symbol.symbol".format(joinTableName, joinTableName)
        return [joinCondition]
    else:
        joinCondition = row["join_condition"]
        return map(lambda item: item.strip(), joinCondition.split(","))


@api_screen.route("/screen/sort_columns", methods=['GET'])
def getScreenSortColumns():
    sql = """select field as id ,name from screen_sort_columns;"""
    sortColumns = dbutil.getDataTable(sql)
    return jsonify(sortColumns)
