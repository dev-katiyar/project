from flask import Flask
from MyConfig import MyConfig as cfg
import utils
from flask import request, make_response, jsonify
import stripe_payment
import dbutil
import json
import login
import email_util
from flask import Blueprint

api_tpa = Blueprint('api_tpa', __name__)
from flask import Blueprint

blog_table = "tpa_blogs"


@api_tpa.route("/blog", methods=['POST'])
def saveBlog():
    post_data = json.loads(request.data)
    title = post_data["title"].encode("ascii", "ignore").replace("'", "\\'")
    content = post_data["content"].encode("ascii", "ignore").replace("'", "\\'")
    sql = """insert into {} (title,content,date) values ('{}','{}' ,'{}')""" \
        .format(blog_table, title, content, post_data["date"])
    print sql
    id = dbutil.insertQuery(sql)

    return jsonify({"status": "success", "id": id, "message": "Post Saved Successfully"})


@api_tpa.route("/updateBlog", methods=['POST'])
def updateBlog():
    post_data = json.loads(request.data)
    title = post_data["title"].encode("ascii", "ignore").replace("'", "\\'")
    content = post_data["content"].encode("ascii", "ignore").replace("'", "\\'")
    content = utils.removeNonAscii(content)
    title = utils.removeNonAscii(title)
    sql = "update {} set title ='{}',content = '{}' where id = {}" \
        .format(blog_table, title, content, post_data["id"])

    dbutil.saveDataQuery(sql)
    return jsonify({"status": "success", "message": "Post Saved Successfully"})


@api_tpa.route("/blog/id/<id>", methods=['GET'])
def getBlog(id):
    sql = "select * from {} where id ={}".format(blog_table, id)
    data = dbutil.getDataTable(sql)
    data = utils.removeNonAsciiFromColumn(data, "content")
    data = utils.removeNonAsciiFromColumn(data, "title")
    return jsonify(data)


@api_tpa.route("/blog/<id>", methods=['Delete'])
def deleteBlog(id):
    sql = "delete from {} where id ={}".format(blog_table, id)
    dbutil.saveDataQuery(sql)
    return jsonify({"status": "success", "message": "Post Deleted Successfully"})


@api_tpa.route("/blog/<searchText>", methods=['GET'])
def searchPost(searchText):
    if searchText != 'NA':
        sql = "select id,title,substring(content,1,2000) as content,date from {}  where title like '%{}%' or content like '%{}%' order by date desc;" \
            .format(blog_table, searchText, searchText)
    else:
        sql = "select id,title,substring(content,1,2000) as content , date from {} order by date desc".format(
            blog_table)
    print sql

    data = dbutil.getDataTable(sql)
    data = utils.removeNonAsciiFromColumn(data, "content")
    data = utils.removeNonAsciiFromColumn(data, "title")
    return jsonify(data)


@api_tpa.route("/user/tpaAmdin", methods=['GET'])
def checkTPAAdminUser():
    userType = 0
    viewType = 'invalid-user'  # user needs to upgrade
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        email = token["data"]["email"]
        data = dbutil.getOneRow("""
        select  coalesce(admin_type,0) as admin_type,substype from users where userid ={}
            """.format(userId))
        admin_type = data["admin_type"]
        substype = data["substype"]
        viewType = getViewType(substype, admin_type)
        return jsonify({"viewType": viewType})


def getViewType(substype, admin_type):
    if (int(admin_type) == 2):
        viewType = 'admin'
    elif (substype in ["3", "4", "5"]):
        viewType = 'valid-user'
    else:
        viewType = 'invalid-user'
    return viewType
