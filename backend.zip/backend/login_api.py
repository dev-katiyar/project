from flask import Flask
from MyConfig import MyConfig as cfg
from flask import request, make_response, jsonify
import stripe_payment

import dbutil
import json
from datetime import datetime
import login
import email_util

from flask import Blueprint

api_login = Blueprint('api_login', __name__)


@api_login.route('/login', methods=['POST'])
def login_api():
    requestParams = request.get_json()
    return login.post(requestParams)


@api_login.route("/contact", methods=['POST'])
def contactUs():
    email = ""
    post_data = json.loads(request.data)
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        email = dbutil.getOneRow(
            "select emailAddress from users where userid ={}".format(userId),
            "emailAddress")
    else:
        email = post_data['email']
    post_data = json.loads(request.data)
    email_list = cfg.admin_users_emails + "," + email
    body = " Dear  {} Thanks for writing to us , We will get back  to you shortly with resolution. <br/> Your Query : {}".format(
        email, post_data['body'])
    email_util.sendEmail(post_data['subject'], body,
                         email_list)
    return jsonify({"status": "ok"})


@api_login.route('/user/check', methods=['POST'])
def emailExistCheck():
    post_data = json.loads(request.data)
    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from users where emailAddress ='{}'".format(post_data['email']),
        "count")
    if existingUserCount == 0:
        return make_response(jsonify({"status": "ok"})), 200

    else:
        return make_response(jsonify({"status": "error",
                                      "message": "You are already registered to our platform , Please login with your email/password , It will take you to upgrade Page."})), 200


@api_login.route('/user/update_creditcard', methods=['POST'])
def update_credit_card():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        post_data = json.loads(request.data)
        card_id = post_data['card_id']
        stripe_payment.updateCard(userId, card_id)
        return make_response(jsonify({"status": "ok", "message": "Credit Card Updated"})), 200
    else:
        return make_response(jsonify(token)), 401


@api_login.route('/upgrade', methods=['POST'])
def upgrade():
    try:
        post_data = json.loads(request.data)
        userId = post_data["userId"]
        sql = "select emailAddress as email  from users where userId = {}".format(userId)
        email = dbutil.getOneRow(sql, "email");
        post_data["email"] = email
        stripe_customer = stripe_payment.create_customer_and_subscription(post_data)

        sqlUpdate = "update users set isPaid = 1 , stripe_user_id ='{}', substype = '{}' where userID ={}".format(
            stripe_customer.id,
            post_data["subscription"]
            , userId)
        dbutil.saveDataQuery(sqlUpdate)
        return make_response(jsonify({"status": "ok"})), 200
    except Exception as ex:
        return make_response(jsonify({"status": "error", "message": "Issue In Upgrading User " + ex.message})), 200


@api_login.route('/free-trial', methods=['POST'])
def FreeTrial():
    post_data = json.loads(request.data)

    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from users where emailAddress ='{}'".format(post_data['email']),
        "count")
    if existingUserCount == 0:
        try:
            sql = """insert into users(firstname,lastname,`password`,username,emailaddress,ispaid,isundertrial,substype,date)
          values('{}','{}','{}','{}','{}',{},{},'{}',CURDATE())""".format(post_data['firstName'],
                                                                          post_data['lastName'],
                                                                          post_data['password'],
                                                                          post_data['email'],
                                                                          post_data['email'], 1, 1, "free-trial")
            dbutil.saveDataQuery(sql);
            body_email = dbutil.getOneRow("select email_new from template", "email_new")
            body_email = body_email.replace("USER$", post_data['email'])
            body_email = body_email.replace("PWD$", post_data['password'])

            email_util.sendEmail("Welcome to SimpleVisor", body_email, post_data['email'])
            return make_response(
                jsonify({"status": "ok", "message": "Congratulations! You are registered for Free Trial. "})), 200
        except Exception, ex:
            return make_response(
                jsonify({"status": "error", "message": "Issue in Free Registration " + ex.message})), 200

    else:
        return make_response(jsonify({"status": "error",
                                      "message": "You are already registered to our platform. Please login with your email/password , it will take you to upgrade Page."})), 200


@api_login.route('/forgotPassword', methods=['POST'])
def forgotPassword():
    post_data = json.loads(request.data)
    email = post_data['email']
    password = dbutil.getOneRow(
        "select password  from users where emailAddress = '{}';".format(email), "password")
    body_email = dbutil.getOneRow("select password_recovery_new from template", "password_recovery_new")
    if password is not None:
        body_email = body_email.replace("USER$", email)
        body_email = body_email.replace("PWD$", password)
        email_util.sendEmail("Password Recovery", body_email, email)
        return jsonify({"status": "ok"})
    else:
        return jsonify({"status": "Following email does not exist in our database"})


@api_login.route("/user/isAdmin", methods=['GET'])
def checkAdminUser():
    userType = 0
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        email = token["data"]["email"]
        admin_type = dbutil.getOneRow("select admin_type from users where userid ={}".format(userId), "admin_type")
    return jsonify({"userType": admin_type})

    return jsonify({"success": "ok"})


@api_login.route('/register', methods=['POST'])
def register():
    post_data = json.loads(request.data)
    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from users where emailAddress ='{}'".format(post_data['email']),
        "count")
    if existingUserCount == 0:
        try:
            stripe_customer = stripe_payment.create_customer_and_subscription(post_data)

            sql = """insert into users(firstname,lastname,`password`,emailaddress,username,ispaid,isundertrial,substype,stripe_user_id,promoCode,date)
          values('{}','{}','{}','{}','{}',{},{},'{}','{}','{}',CURDATE())""".format(post_data['firstName'],
                                                                                    post_data['lastName'],
                                                                                    post_data['password'],
                                                                                    post_data['email'],
                                                                                    post_data['email'], 1, 0,
                                                                                    post_data["subscription"],
                                                                                    stripe_customer.id,
                                                                                    post_data["promoCode"]
                                                                                    )
            dbutil.saveDataQuery(sql);
            body_email = dbutil.getOneRow("select email from template", "email")
            body_email = body_email.replace("USER$", post_data['email'])
            body_email = body_email.replace("PWD$", post_data['password'])

            email_util.sendEmail("Welcome to SimpleVisor Platform", body_email, post_data['email'])

            return make_response(jsonify({"status": "ok"})), 200

        except Exception, ex:
            print(ex)
            return make_response(jsonify({"status": "error", "message": "Issue In Payment " + ex.message})), 200

    else:
        return make_response(jsonify({"status": "error",
                                      "message": "You are already registered to our platform , Please login with your email/password , It will take you to Upgrade Page."})), 200


@api_login.route("/register/questions", methods=['GET'])
def getQuestions():
    risk_tolerance = dbutil.getDataTable("select * from risk_tolerance")
    financial_goals = dbutil.getDataTable("select * from financial_goals")
    return jsonify({"risk_tolerance": risk_tolerance, "financial_goals": financial_goals})


@api_login.route("/subscriptions/<type>", methods=['GET'])
def getSubscriptions(type):
    if type == "all":
        sql = """select name,id from subscriptions"""
    else:
        sql = """select name,id from subscriptions where id in (4,5)"""
    data = dbutil.getDataTable(sql)
    return jsonify(data)


@api_login.route('/users/changePassword', methods=['POST'])
def setNewPassword():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
    post_data = json.loads(request.data)
    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from users where password ='{}' and userId = {};".format(post_data['oldPassword'],
                                                                                           userId), "count")
    if existingUserCount == 1:
        dbutil.saveDataQuery("""update users set password = '{}' where userId = {} and password = '{}'""".format(
            post_data['newPassword'],
            userId, post_data['oldPassword']));
        return make_response(jsonify({"status": "ok", "message": "You have Successfully Changed your Password"})), 200
    else:
        return make_response(jsonify({"status": "ok", "message": "Incorrect Old Password"})), 200


@api_login.route('/email/subscription/<userId>', methods=['GET'])
def unsubscribeEmailByUserId(userId):
    return make_response(
        jsonify({"status": "ok",
                 "message": "Please login and go to profile to unsubscribe https://simplevisor.com/profile"})), 200;


@api_login.route('/email/subscription', methods=['POST'])
def unsubscribeEmailPost():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
    post_data = json.loads(request.data)
    action = post_data["action"]
    return unSubscribeEmail(userId, action)


def unSubscribeEmail(userId, action):
    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from unsubscribe_user where user_id = {};".format(userId), "count");
    if action == "unsubscribe":
        if existingUserCount == 0:
            dbutil.saveDataQuery(
                """insert into unsubscribe_user (user_id,subscription_type,date) values({},{},CURDATE());""".format(
                    userId, 1));
            return make_response(
                jsonify({"status": "success", "message": "You have been unsubscribed from daily emails."})), 200
        else:
            return make_response(
                jsonify({"status": "error", "message": "You are already Unsubscribed for daily emails."})), 200;

    elif action == "subscribe":
        if existingUserCount == 0:
            return make_response(
                jsonify({"status": "error", "message": "You are already Subscribed for daily emails."})), 200
        else:
            dbutil.saveDataQuery(
                """delete from unsubscribe_user where user_id = {};""".format(userId));
            return make_response(jsonify({"status": "success", "message": "You have been subscribed to emails."})), 200


@api_login.route('/user/subscription', methods=['POST'])
def updateUserInfo():
    post_data = json.loads(request.data)
    token = login.checkToken(request)
    action = post_data["action"]
    # print post_data
    message = ""
    status = "success"
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        email = token["data"]["email"]
        if action == "unsubscribe":
            unsubscribePlan(userId, email)
            message = "You have been Unsubscribed from SimpleVisor. Thanks for Using our platform"

        elif action == "changeSubscription":
            status, message = changeUserSubscription(post_data, userId)


        elif action == "update":
            # update user info here
            updateUserInfo(post_data, userId)
            message = "Information Updated !"
        elif action == "subscribe":
            status, message = reactivateSubscription()
        elif action == "register":
            status, message = register(post_data)

    else:
        status = "error"
        message = "Invalid User !"

    return make_response(jsonify({"status": status, "message": message})), 200


def changeUserSubscription(post_data, userId):
    newSubsType = post_data["subscriptionId"]
    sql = "select stripe_user_id ,emailAddress from users where userid ={}".format(userId)
    row = dbutil.getOneRow(sql)
    stripe_customer_id = row["stripe_user_id"]
    emailUser = row["emailAddress"]
    email_list = "vinodnayal1981@gmail.com"
    newPlan = cfg.plans[str(newSubsType)]
    body = "Subscription changed for User {} to {} plan {}".format(emailUser, newSubsType, newPlan)
    email_util.sendEmail("User Changed Subscription", body, email_list)
    stripe_payment.modifySubscription(stripe_customer_id, newPlan)
    sql = """update users set substype = {} where userid = {}""".format(
        newSubsType, userId)
    data = dbutil.saveDataQuery(sql)
    return "ok","User Subscription Changed !"


def updateUserInfo(post_data, userId):
    post_data = json.loads(request.data)
    query = """update users 
    set firstName = '{}' ,
    lastName ='{}',emailAddress ='{}',password ='{}',
	age ='{}',martial_status = '{}',dependents = '{}',
	financial_goals = '{}',risk_tolerance = '{}'
    where userId = {}
    """.format(
        post_data['userData']['firstName'],
        post_data['userData']['lastName'],
        post_data['userData']['emailAddress'],
        post_data['userData']['password'],
        post_data['userData']['age'],
        post_data['userData']['martial_status'],
        post_data['userData']['dependents'],
        post_data['userData']['financial_goals'],
        post_data['userData']['risk_tolerance'],
        userId)
    print(query)
    dbutil.saveDataQuery(query);


def register(post_data):
    existingUserCount = dbutil.getOneRow(
        "select count(*) as count from users where emailAddress ='{}'".format(post_data['email']),
        "count")
    if existingUserCount == 0:
        try:
            stripe_customer = stripe_payment.create_customer_and_subscription(post_data)

            sql = """insert into users(firstname,lastname,`password`,emailaddress,username,ispaid,isundertrial,substype,stripe_user_id,promoCode,date)
          values('{}','{}','{}','{}','{}',{},{},'{}','{}','{}',CURDATE())""".format(post_data['firstName'],
                                                                                    post_data['lastName'],
                                                                                    post_data['password'],
                                                                                    post_data['email'],
                                                                                    post_data['email'], 1, 0,
                                                                                    post_data["subscription"],
                                                                                    stripe_customer.id,
                                                                                    post_data["promoCode"]
                                                                                    )
            dbutil.saveDataQuery(sql);
            body_email = dbutil.getOneRow("select email_new from template", "email_new")
            body_email = body_email.replace("USER$", post_data['email'])
            body_email = body_email.replace("PWD$", post_data['password'])

            email_util.sendEmail("Welcome to SimpleVisor!", body_email, post_data['email'])

            return "success", "ok"
        except Exception, ex:
            return "error", "Issue In Payment"
    else:
        return "error", "You are already registered to our platform , Please login with your email/password , It will take you to upgrade Page."


def unsubscribePlan(userId, email):
    dbutil.saveDataQuery(
        """update users set isPaid = 0 where userId ={};""".format(userId));
    sql = "SELECT stripe_user_id FROM users where userId = {}".format(userId)
    # stripe_user_id = dbutil.getOneRow(sql, "stripe_user_id")
    stripe_payment.cancelSubscription(userId)
    email_util.sendEmail("User Unsubscription Confirmation.",
                         """Dear User ,
                             You have been unsubscribed from SimpleVisor, Thanks for using our platform.""",
                         email)


def reactivateSubscription():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        email = token["data"]["email"]
        dbutil.saveDataQuery(
            """update users set isPaid = 1 where userId ={};""".format(userId));
        stripe_payment.redActivateSubscription(userId)
        return "ok", "You have been Subscribed again to SimpleVisor !"
    else:
        return "error", "Invalid Stripe User."


@api_login.route('/user/subscription', methods=['GET'])
def getSubscriptionPlan():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        sql = """SELECT isPaid,s.id as subscriptionId ,
        coalesce(s.name,'Monhtly') as subscriptionName,
        date,stripe_user_id,password,age,dependents,martial_status,emailAddress,
        firstName,lastName,u.risk_tolerance,u.financial_goals 
        FROM users u 
        left join subscriptions s 
        on u.substype = s.id
        left join risk_tolerance r
        on u.risk_tolerance = r.id
        left join financial_goals f
        on u.financial_goals = f.id
         where u.userId = {}""".format(userId)
        data = dbutil.getOneRow(sql)
        return jsonify(data)
    else:
        return make_response(jsonify(token)), 401


@api_login.route("/users/details", methods=['POST'])
def getAllUsersDetails():
    post_data = json.loads(request.data)
    sql = """SELECT userId,username,password,firstName,lastName,emailAddress, 
        isPaid,promoCode,
         DATE_FORMAT(date, "%Y-%m-%d") as date
        FROM users where emailAddress   like '%{}%' 
             or  firstname like '%{}%' 
    """.format(post_data, post_data)
    data = dbutil.getDataTable(sql)
    return jsonify(data)


@api_login.route('/user/details', methods=['POST'])
def updateUserDetails():
    post_data = json.loads(request.data)
    action = post_data["action"]
    if action == "add":
        sql = """insert into users(username,firstName,lastName,emailAddress, isPaid,date,password) values ('{}','{}','{}','{}','{}','{}','{}')""".format(
            post_data['username'], post_data['firstName'], post_data['lastName'],
            post_data['emailAddress'], post_data['isPaid'], datetime.today(), post_data['password'])

    elif action == "delete":
        sql = """delete from users where userId ='{}'""".format(post_data['userId'])

    elif action == "save":
        sql = """update users set username='{}',firstName='{}',lastName='{}',emailAddress='{}', isPaid='{}',password='{}' where userId = {} ;""" \
            .format(post_data['username'], post_data['firstName'], post_data['lastName'], post_data['emailAddress'],
                    post_data['isPaid'], post_data['password'], post_data['userId'])

    data = dbutil.saveDataQuery(sql)
    return jsonify(data)


@api_login.route('/default_emails_to_users', methods=['POST'])
def defaultEmails():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        dbutil.saveDataQuery(
            """insert into user_email_subscription (userId,riapro_portfolio,my_portfolio,watchlist,dashboard) values({},{},{},{},{});""".format(
                userId, 1, 1, 1, 1));
        return make_response(jsonify(token)), 200
    else:
        return make_response(jsonify(token)), 401
