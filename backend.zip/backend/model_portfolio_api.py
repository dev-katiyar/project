
import utils
from flask import request, make_response, jsonify
import dbutil
import portfolioManager as pm
import json
import login
from flask import Blueprint
import datetimeutil
from datetime import timedelta

api_model_portfolio = Blueprint('api_model_portfolio', __name__)

BENCHMARK_PORTFOLIO_BOND_ID = 19
BENCHMARK_PORTFOLIO_EQUITY_ID = 6


def getBenchMark(modelPortfolioId):
    return [BENCHMARK_PORTFOLIO_EQUITY_ID, BENCHMARK_PORTFOLIO_BOND_ID]


@api_model_portfolio.route("/modelportfolio/dataready/<portfolioId>", methods=['GET'])
def dataReady(portfolioId):
    stillProcessing = dbutil.getOneRow("select  distinct id from editportfolio where id = {}".format(portfolioId))
    if stillProcessing:
        return jsonify({"status": 0})
    else:
        return jsonify({"status": 1})


@api_model_portfolio.route("/modelportfolio/historical", methods=['POST'])
def getModelPortfolioHistoricalData():
    post_data = json.loads(request.data)
    portfolioId = int(post_data["portfolio"])

    first_transaction_date = dbutil.getFirstTransaction(portfolioId)
    first_transaction_date = datetimeutil.getdatetime(datetimeutil.getdatefromstr(first_transaction_date)) - timedelta(
        days=5)
    first_transaction_date = datetimeutil.getdatestr(first_transaction_date)
    period = post_data["period"];
    benchMarkIds = getBenchMark(portfolioId)
    all_portfolioIds = [portfolioId]
    all_portfolioIds.extend(benchMarkIds)
    sql = "select portfolioid as portfolio_id,name as portfolio_name from model_portfolio where portfolioid in  ({})".format(
        ",".join(map(str, all_portfolioIds)))
    nameMap = dbutil.getKeyValuePair(sql, "portfolio_id", "portfolio_name")
    portfolioCurrentData = getCurrentPortfolioValues(portfolioId)
    todayvalues = {}
    for benchMarkId in benchMarkIds:
        benchMarkCurrentData = getCurrentPortfolioValues(benchMarkId)
        todayvalues.update({benchMarkId: benchMarkCurrentData["portfolioDetails"]["portfolioValue"]})
    todayvalues.update({portfolioId: portfolioCurrentData["portfolioDetails"]["portfolioValue"]})

    df_historical = dbutil.getPortfolioHistorical("model_portfolio_historical_data", all_portfolioIds, nameMap,
                                                  period,
                                                  first_transaction_date, todayvalues)
    return dbutil.df_to_json(df_historical)


@api_model_portfolio.route("/modelportfolio/performance/<portfolioId>", methods=['GET'])
def getModelPortfolioPerformance(portfolioId):
    portfolioId = int(portfolioId)
    first_transaction_date = dbutil.getFirstTransaction(portfolioId)
    first_transaction_date = datetimeutil.getdatetime(datetimeutil.getdatefromstr(first_transaction_date)) - timedelta(
        days=5)
    first_transaction_date = datetimeutil.getdatestr(first_transaction_date)
    benchMarkIds = getBenchMark(portfolioId)
    all_portfolioIds = [portfolioId]
    all_portfolioIds.extend(benchMarkIds)
    sql = "select portfolioid as portfolio_id,name as portfolio_name from model_portfolio where portfolioid in  ({})".format(
        ",".join(map(str, all_portfolioIds)))
    nameMap = dbutil.getKeyValuePair(sql, "portfolio_id", "portfolio_name")
    portfolioCurrentData = getCurrentPortfolioValues(portfolioId)
    todayvalues = {}
    for benchMarkId in benchMarkIds:
        benchMarkCurrentData = getCurrentPortfolioValues(benchMarkId)
        todayvalues.update({benchMarkId: benchMarkCurrentData["portfolioDetails"]["portfolioValue"]})
    todayvalues.update({portfolioId: portfolioCurrentData["portfolioDetails"]["portfolioValue"]})
    data = dbutil.performanceDataByPeriod("model_portfolio_historical_data", all_portfolioIds, nameMap, '3year',
                                          first_transaction_date, todayvalues)

    return jsonify(data)


def getCurrentPortfolioValues(id):
    portfolioData = {}
    transactions = dbutil.getTransactions(id)
    cash_transactions = dbutil.get_cash_transactions(id)
    listSymbols = utils.getArrayFromColumn(transactions, "symbol")
    portfolioDetails = dbutil.getModelPortfolioDetails(id)

    openPositions, closedPositions = pm.createPositionsFromTransactions(transactions)
    # set current cash onm portfolioDetails
    pm.setCurrentCash(portfolioDetails, openPositions, closedPositions, transactions)
    listOpenSymbols = utils.getArrayFromColumn(openPositions, "symbol")
    basicDetails = dbutil.getBasicDetails(listSymbols)

    pm.calculatePortfolioDetails(portfolioDetails, cash_transactions, basicDetails,
                                 openPositions)
    transactions.sort(key=lambda x: x["date"], reverse=True)
    portfolioData['transactions'] = transactions
    portfolioData['cash_transactions'] = cash_transactions
    portfolioData['portfolioDetails'] = portfolioDetails
    portfolioData['openPositions'] = openPositions
    portfolioData['closedPositions'] = closedPositions
    portfolioData['basicDetails'] = basicDetails
    return portfolioData


# get all portfolio Ids
@api_model_portfolio.route("/modelportfolio/all/<portfolio_type>", methods=['GET'])
def getSelectedPortfolios(portfolio_type):
    userId = 0
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
    allPortfolios = dbutil.getModelPortfolios(userId, portfolio_type)
    return jsonify(allPortfolios)


@api_model_portfolio.route("/modelportfolio", methods=['POST'])
def saveModelPortfolio():
    userId = 0
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
    data = json.loads(request.data)
    action = data["action"]
    portfolioId = data["id"]
    cash = 0
    name = ""
    if action == "delete":
        dbutil.deletePortfolio(portfolioId)
    else:
        name = data["name"]
        if 'startingCash' in data:
            cash = data["startingCash"]
        if 'name' in data:
            name = data["name"]
        if portfolioId == 0:  # add
            portfolioId = dbutil.createNewPortflio(name, cash, userId, data["portfolio_type"])
        else:
            if name != '' and cash != 0:
                dbutil.updateModelPortfolio(portfolioId, cash, name)
        if "newTransactions" in data:
            newTransactions = data["newTransactions"]
            if (len(newTransactions) > 0):
                dbutil.saveTransactions(portfolioId, newTransactions)
        if "updatedTransactions" in data:
            updatedTransactions = data["updatedTransactions"]
            if (len(updatedTransactions) > 0):
                dbutil.updateTransactions(portfolioId, updatedTransactions)
        if "deletedTransactions" in data:
            deletedTransactions = data["deletedTransactions"]
            if (len(deletedTransactions) > 0):
                dbutil.deleteTransactions(portfolioId, deletedTransactions)
        sqlCalc = "insert into editportfolio(id,portfolioOrwatch) value ({},3)".format(portfolioId);
        dbutil.saveDataQuery(sqlCalc)
    return jsonify({"success": "0", "action": action, "data": {"id": portfolioId, "name": name}})


# get data for a portfolio
@api_model_portfolio.route("/modelportfolio/<id>", methods=['GET'])
def getPortfolioData(id):
    portfolioData = getCurrentPortfolioValues(id)
    return jsonify(portfolioData)
