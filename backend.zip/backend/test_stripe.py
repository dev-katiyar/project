import stripe
from MyConfig import MyConfig as cfg
import dbutil

stripe.api_key = cfg.stripe_private_key

customer = stripe.Customer.retrieve("cus_FkGB97fo4yRXBt")
# print customer["subscriptions"]
subscription_id = customer["subscriptions"]["data"][0]["id"]
subscription = stripe.Subscription.retrieve(subscription_id)

print subscription.id
print subscription['items']['data'][0].id
#exit()
cancel_at_period_end = True
stripe.Subscription.modify(
    subscription.id,
    cancel_at_period_end=False,
    proration_behavior='create_prorations',
    items=[{
        'id': subscription['items']['data'][0].id,
        'plan': 'plan_HJW6zclDN4iwNp',
    }]
    # plan plan_HJW6zclDN4iwNp
)
