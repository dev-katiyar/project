from __future__ import print_function
import json
from MyConfig import MyConfig as cfg
from flask import request, make_response, jsonify
from datetime import datetime
from flask import Blueprint
import datetimeutil
import pytz
import pandas as pd
import requests
import dbutil
import numpy as np

api_rapid = Blueprint('api_rapid', __name__)
est = pytz.timezone('US/Eastern')
utc = pytz.utc


def corrected_data(ohlcData, columnname):
    return map(lambda x: x if x is not None else 0, ohlcData[columnname])


@api_rapid.route("/symbol/option/<ticker>", methods=['GET'])
def getOptionsExpiration(ticker):
    url = "{}/v7/finance/options/{}".format(cfg.RAPID_BASE_API, ticker)
    querystring = {"symbol": ticker}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    result = json.loads(response.text)
    result = result["optionChain"]["result"][0]["expirationDates"]
    date_formatted = map(lambda x: createTempMap(x), result)
    return jsonify(date_formatted)


def createTempMap(utc_date):
    dateTime = datetime.fromtimestamp(utc_date)
    return {"id": utc_date, "name": dateTime.strftime('%B %d, %y')}


@api_rapid.route("/symbol/option/<ticker>/<expiration>", methods=['GET'])
def getOptionsFullData(ticker, expiration):
    url = "{}/v7/finance/options/{}".format(cfg.RAPID_BASE_API, ticker)
    querystring = {"symbol": ticker, "date": expiration}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    result = json.loads(response.text)
    result = result["optionChain"]["result"][0]["options"][0]
    result["calls"] = map(lambda x: formatDatesOptions(x), result["calls"])
    result["puts"] = map(lambda x: formatDatesOptions(x), result["puts"])
    return jsonify(result)


def formatDatesOptions(row):
    row["lastTradeDate"] = datetime.fromtimestamp(row["lastTradeDate"]).strftime('%B %d, %y')
    return row


@api_rapid.route("/market/summary", methods=['GET'])
def getMarketSummary():
    url = "{}/v6/finance/quote/marketSummary".format(cfg.RAPID_BASE_API)
    querystring = {"region": "US", "lang": "en"}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    result = jsonData["marketSummaryResponse"]["result"]
    result = filter(lambda x: x["quoteType"] != "CRYPTOCURRENCY", result)
    result = map(lambda x: createMarkeySummaryObj(x), result)
    return jsonify(result)


def createMarkeySummaryObj(x):
    # print(x)
    y = {}
    y["shortName"] = x["shortName"]
    y["symbol"] = x["symbol"]
    y["change"] = x["regularMarketChange"]["fmt"]
    return y


def get_symbol_quotes_data(symbols):
    url = "{}/v6/finance/quote".format(cfg.RAPID_BASE_API)
    querystring = {"lang": "en", "symbols": ','.join(symbols)}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    yf_quote_data = jsonData['quoteResponse']['result']
    return yf_quote_data


def get_suggested_symbols(symbol):
    url = "{}/v6/finance/autocomplete".format(cfg.RAPID_BASE_API)
    querystring = {"lang": "en", "query": ','.join(symbol)}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    yf_suggested_symbols = jsonData['ResultSet']['Result']
    return yf_suggested_symbols


def get_symbol_profile_data(symbol):
    url = "{}/v11/finance/quoteSummary/{}".format(cfg.RAPID_BASE_API, symbol)
    querystring = {"modules": "quoteType,assetProfile"}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    yf_profile_data = jsonData['quoteSummary']['result'][0]
    return yf_profile_data


def get_stats_data(ticker):
    url = "{}/v11/finance/quoteSummary/{}".format(cfg.RAPID_BASE_API, ticker)
    querystring = {"modules": "earnings,summaryDetail,financialData,defaultKeyStatistics"}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }
    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    data = jsonData['quoteSummary']['result'][0]
    baseData = data.get('defaultKeyStatistics', {})
    earnings = data.get('earnings', {})
    summaryDetail = data.get('summaryDetail', {})
    financialData = data.get('financialData', {})

    baseData.update(summaryDetail)
    baseData.update(financialData)
    baseData.update(earnings)
    # print(baseData)
    result = {}
    for key, value in baseData.iteritems():
        if isinstance(value, dict) and 'fmt' in value:
            result.update({key: value['fmt']})
    result["symbol"] = ticker
    return result


@api_rapid.route("/symbol/recommendations/<ticker>", methods=['GET'])
def getSymbolRecommmendations(ticker):
    url = "{}/v6/finance/recommendationsbysymbol/{}".format(cfg.RAPID_BASE_API, ticker)
    # querystring = {"modules": "price,summaryDetail,financialData,defaultKeyStatistics"}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }
    response = requests.request("GET", url, headers=headers)
    jsonData = json.loads(response.text)
    symbolsData = jsonData['finance']['result'][0]['recommendedSymbols']
    # print (symbolsData)
    return jsonify(symbolsData)


def filterSelectedColumns(obj, listColumns):
    res_dict = {}
    for typeKey, row in obj.iteritems():
        if typeKey in listColumns and isinstance(row, list):
            row_list = []
            for item in row:
                res = {}
                for key, value in item.iteritems():
                    if (key in listColumns[typeKey]):
                        res.update({key: value["fmt"]})
                row_list.append(res)

            res_dict.update({typeKey: row_list})

    return res_dict


@api_rapid.route("/symbol/financialperformance/<ticker>", methods=['GET'])
def getFinancialPerformance(ticker):
    modules = ["incomeStatementHistoryQuarterly", "cashflowStatementHistoryQuarterly", "incomeStatementHistory",
               "cashflowStatementHistory"]
    formattedModules = ",".join(modules)
    url = "{}/v11/finance/quoteSummary/{}".format(cfg.RAPID_BASE_API, ticker)
    querystring = {
        "modules": formattedModules}
    headers = {
        'x-api-key': cfg.RAPID_KEY
    }
    response = requests.request("GET", url, headers=headers, params=querystring)
    jsonData = json.loads(response.text)
    # print (jsonData)
    all_data_quaterly = {}
    modulesQuaterly = ["incomeStatementHistoryQuarterly", "cashflowStatementHistoryQuarterly"]
    for module in modulesQuaterly:
        all_data_quaterly.update(jsonData['quoteSummary']['result'][0][module])
        print(all_data_quaterly)
    all_data_yearly = {}
    modulesYearly = ["incomeStatementHistory", "cashflowStatementHistory"]
    for module in modulesYearly:
        all_data_yearly.update(jsonData['quoteSummary']['result'][0][module])

    listColumns = {"cashflowStatements": ["dividendsPaid", "endDate"],
                   "incomeStatementHistory": ["netIncome", "totalRevenue", "grossProfit", "endDate"]
                   }

    selectedQuaterly = filterSelectedColumns(all_data_quaterly, listColumns)
    selectedYearly = filterSelectedColumns(all_data_yearly, listColumns)
    return jsonify({"quaterly": selectedQuaterly, "yearly": selectedYearly})


def get_price_field(column, row):
    if row[column]:
        return round(float(row[column].replace(",", "")), 2)
    else:
        return 0


@api_rapid.route("/symbol/keystats/<ticker>", methods=['GET'])
def getKeyStats(ticker):
    data = get_stats_data(ticker)
    return jsonify(data)


@api_rapid.route("/fundamental/peer/<ticker>", methods=['GET'])
def getFundamentalPeersNew(ticker):
    mapping = dbutil.getDataDict("select * from stats_ticker_mapping", "name")
    result = {}
    peerSymbols = dbutil.getPeers(ticker)
    if ticker not in peerSymbols:
        peerSymbols.append(ticker)
    if len(peerSymbols) == 0:
        return jsonify(result)

    formattedSymbols = map(lambda x: "'" + x + "'", peerSymbols)
    formattedSymbols = ','.join(formattedSymbols)
    row_stats = {}
    all_symbol_stats = []
    for peerSymbol in peerSymbols:
        stats_data = get_stats_data(peerSymbol)
        all_symbol_stats.append(stats_data)
    for row in all_symbol_stats:
        symbol_row = row['symbol']
        row['52weekrange'] = str(get_price_field("fiftyTwoWeekLow", row)) + " - " + str(
            get_price_field("fiftyTwoWeekHigh", row))
        if 'fiftyTwoWeekHigh' in row and 'regularMarketPrice' in row:
            row['below_high'] = 100 * (
                    get_price_field("fiftyTwoWeekHigh", row) - get_price_field("regularMarketPrice",
                                                                               row)) / get_price_field(
                "regularMarketPrice", row)
        if row['regularMarketDayLow']:
            row['todayrange'] = str(get_price_field("fiftyTwoWeekLow", row)) + " - " + str(
                get_price_field("fiftyTwoWeekHigh", row))
        for column, mappingItem in mapping.iteritems():
            group = mappingItem['group']
            display_name = mappingItem['display_name']
            type = mappingItem['type']

            if column in row:
                row_val = row[column]

                if row_val is not None and type == "text" and "-" not in row_val and row_val != 'na':
                    row_val = row_val
                # elif row_val is not None and type == "percentage" and row_val != 'na':
                #     if utils.isNumber(row_val):
                #         row_val = float(row_val) * 100

                if column not in row_stats:
                    row_stats.update({column: {'group': group, 'data': {}, 'display_name': display_name, 'type': type}})

                if symbol_row == ticker:
                    row_stats[column].update({'symbol_value': row_val})
                else:
                    row_stats[column]['data'].update({symbol_row: row_val})

    peer_data = []
    for column, value in row_stats.iteritems():
        if 'symbol_value' in value:
            row_data = {'name': value['display_name'], 'group': value['group'], 'data': value['data'],
                        'symbol_value': value['symbol_value'], 'type': value['type']}

        else:
            row_data = {'name': value['display_name'], 'group': value['group'], 'data': value['data'],
                        'symbol_value': 'na', 'type': value['type']}
        peer_data.append(row_data)

    peerSymbols.remove(ticker)
    result.update({"peer_symbols": peerSymbols})
    result.update({"peer_data": peer_data})
    return jsonify(result)


@api_rapid.route("/iex/hist_prices", methods=['POST', 'GET'])
def get_history_data():
    identifier = request.args.get('identifier')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    interval = request.args.get('interval')
    start_date_obj = datetimeutil.getdatefromstr_format(start_date[:10], "%Y-%m-%d")
    end_date_obj = datetimeutil.getdatefromstr_format(end_date[:10], "%Y-%m-%d")
    current_date = datetime.now()
    if end_date_obj > current_date:
        end_date_obj = current_date

    day_diff = (end_date_obj - start_date_obj).days
    interval = "1d"
    if day_diff < 10:
        range = "5d"
        interval = "5m"
    elif day_diff < 100:
        range = "5d"
        interval = "5m"
    elif day_diff < 400:
        range = "3mo"
    elif day_diff < 500:
        range = "6mo"
    elif day_diff < 500:
        range = "6m"
    elif day_diff < 2115:
        range = "1y"
    elif day_diff < 4000:
        range = "5y"
    else:
        range = "max"
        interval = "1wk"

    # if interval == 'minute':
    #     interval = "5m"
    # else:
    #     interval = "1d"

    url = "{}/v8/finance/chart/{}".format(cfg.RAPID_BASE_API, identifier)

    querystring = {"range": range, "interval": interval}

    headers = {
        'x-api-key': cfg.RAPID_KEY
    }

    response = requests.request("GET", url, headers=headers, params=querystring)

    jsonData = json.loads(response.text)

    ohlcData = jsonData['chart']['result'][0]['indicators']['quote'][0]
    timestamps = jsonData['chart']['result'][0]['timestamp']
    date_formatted = map(lambda x: datetime.fromtimestamp(x).strftime('%Y-%m-%d %H:%M'), timestamps)
    high = map(lambda x: round(x, 2), corrected_data(ohlcData, 'high'))
    low = map(lambda x: round(x, 2), corrected_data(ohlcData, 'low'))
    opendata = map(lambda x: round(x, 2), corrected_data(ohlcData, 'open'))
    close = map(lambda x: round(x, 2), corrected_data(ohlcData, 'close'))
    volume = map(lambda x: int(x), corrected_data(ohlcData, 'volume'))
    if 'adjclose' in ohlcData:
        adjcloce_data = jsonData['chart']['result'][0]['indicators']['adjclose'][0]
        adjclose = map(lambda x: round(x, 2), corrected_data(adjcloce_data, 'adjclose'))
    else:
        adjclose = close
    df = pd.DataFrame(
        {'date': date_formatted, 'high': high, 'low': low, 'open': opendata, 'actualclose': close, 'volume': volume,
         'close': adjclose})
    df['symbol'] = identifier
    df = df[['date', 'open', 'high', 'low', 'actualclose', 'volume', 'close', 'symbol']]
    # replace zero with nan and forward fill
    df = df.replace(0, np.nan)
    df = df.fillna(method='pad')
    return jsonify(df.T.to_dict().values())
