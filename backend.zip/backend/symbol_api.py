import utils
from flask import request, make_response, jsonify
import dbutil
import json
from datetime import datetime, timedelta, date
import datetimeutil
from flask import Blueprint
import pandas as pd

api_symbol = Blueprint('api_symbol', __name__)


@api_symbol.route("/symbol/model/<symbols>", methods=['GET', 'POST'])
def getSymbolModelData(symbols):
    if request.method == "POST":
        symbols = json.loads(request.data)
    data = dbutil.getSymbolTechnicalDataAndFundamental(symbols)
    for row in data:
        try:
            ma_34wk = row["sma150"]
            ma_13wk = row["sma50"]
            price = row["price"]
            if price != None and ma_13wk != None:
                stopLoss = ma_34wk * .99
                row['distance_to_stop'] = price - stopLoss
                stop_loss_alert = ""
                if price < stopLoss:
                    stop_loss_alert = "ALERT"
                row['stop_loss_alert'] = stop_loss_alert
                row['stop_loss'] = stopLoss
                row['deviation_from_13wkma'] = price - ma_13wk
                row['deviation_from_34wkma'] = price - ma_34wk
                row['short_trend_text'] = dbutil.get_alert_text(row['short_trend'])
                row['long_trend_text'] = dbutil.get_alert_text(row['long_trend'])
                data_map = {0: "Neutral", 1: "Very Bearish", 2: "Bearish", 3: "Bullish", 4: "Very Bullish"}
                short_trend = row['short_trend']
                inter_trend = row['inter_trend']
                long_trend = row['long_trend']
                buy_signal = ""
                sell_signal = ""
                if ((inter_trend >= 3 or long_trend >= 3) and stop_loss_alert == ""):
                    buy_signal = "Bullish"
                elif (inter_trend == 0 and long_trend == 0):
                    buy_signal = ""
                elif ((inter_trend <= 2 and long_trend <= 2) or stop_loss_alert == ""):
                    sell_signal = "Bearish"
                row['buy_signal'] = buy_signal
                row['sell_signal'] = sell_signal
                if buy_signal != "":
                    row['net_signal'] = sell_signal
                else:
                    row['net_signal'] = sell_signal
        except Exception, ex:
            print
            ex

    return jsonify(data)


@api_symbol.route("/symbol/news/<symbols>", methods=['GET'])
def getNews(symbols):
    limit = 10
    if len(symbols.split(",")) <= 15:
        limit = 20
    news = dbutil.getNews(symbols.split(","), limit)
    return jsonify(news)


@api_symbol.route('/symbol/peers/<symbol>', methods=['GET'])
def getSymbolPeers(symbol):
    peerSymbols = dbutil.getPeers(symbol)
    peerSymbols.append(symbol)
    return jsonify(peerSymbols)


@api_symbol.route('/symbol/arevalid', methods=['POST', 'GET'])
def checkSymbolValidity():
    try:
        if request.method == 'POST':
            data = json.loads(request.data)
            req_symbols = data["symbols"]
        else:
            req_symbols = request.args.get('symbols')
            req_symbols = req_symbols.split(",")
        db_symbols = dbutil.symbolsInListSymbolTable(req_symbols)
        missing_symbols = list(set(req_symbols) - set(db_symbols))
        if len(missing_symbols) == 0:
            return jsonify({"isvalid": 'valid', "invalidsymbol": {}})
        elif len(missing_symbols) > 0:
            yf_symbols = dbutil.checkSymbolsFromYahoo(missing_symbols)
            if len(yf_symbols) > 0:
                list_symbol_data = dbutil.getSymbolDataFromYahoo(yf_symbols)
                dbutil.insertIntoListSymbols(list_symbol_data)
            invalid_symbols = list(set(missing_symbols) - set(yf_symbols))
            if len(invalid_symbols) == 0:
                return jsonify({"isvalid": 'valid', "invalidsymbol": {}})
            elif len(invalid_symbols) > 0:
                invalid_symbol = invalid_symbols[0]
                suggested_symbols = dbutil.getSuggestedSymolsFromYahoo(invalid_symbol)
                return jsonify({
                    "isvalid": 'invalid',
                    "invalidsymbol": {
                        'invalidsymbol': invalid_symbol,
                        'suggestions': suggested_symbols
                    }})
    except Exception, ex:
        return jsonify({"status": "failed", "message": "Problem in validating symbol. {}".format(ex)})


@api_symbol.route('/symbol/details', methods=['POST'])
def addSymbolDetails():
    try:
        post_data = json.loads(request.data)
        action = post_data["action"]
        if action == "get":
            symbol = post_data["symbol"]
            sql = """SELECT ls.symbol FROM list_symbol ls
            where ls.symbol like '{}%' and ls.isactive = 1""".format(symbol)
            symbol_list = dbutil.getDataArray(sql)
            data = dbutil.getSymbolTechnicalDataAndFundamental(",".join(symbol_list))
            return jsonify(data)
        elif action == "add":
            sql = """insert into list_symbol(symbol,companyname,exchange,source,assetid,sectorid,industryid,isactive) values ('{}','{}','{}','{}',{},{},{},{})""".format(
                post_data['symbol'], post_data['companyname'], post_data['exchange'], post_data['source'],
                post_data['assetid'], post_data['sectorid'], post_data['industryid'], post_data['isactive'])
            data = dbutil.saveDataQuery(sql)
            return jsonify({"status": "success", "message": "Symbol Added"})

        elif action == "delete":

            sql = """delete from list_symbol where symbol ='{}'""".format(post_data['symbol'])
            data = dbutil.saveDataQuery(sql)
            return jsonify({"status": "success", "message": "Symbol Deleted"})

        elif action == "save":
            sql = """update list_symbol set source='{}',companyname='{}',exchange='{}',assetid={} ,sectorid={} ,industryid={} ,isactive={} where symbol = '{}' ;""".format(
                post_data['source'], post_data['companyname'], post_data['exchange'], post_data['asset_id'],
                post_data['sector_id'],
                post_data['industry_id'], post_data['isactive'], post_data['symbol'])
            data = dbutil.saveDataQuery(sql)
            return jsonify({"status": "success", "message": "Symbol Saved"})
    except Exception, ex:
        return jsonify({"status": "failed", "message": "Problem in saving / getting data {}".format(ex)})


@api_symbol.route("/sectors", methods=['GET'])
def getSectors():
    data = dbutil.getDataTable("select id,name from sectors;")
    return jsonify(data)


@api_symbol.route("/assets", methods=['GET'])
def getAssets():
    sqlAsset = """select distinct asset_name from assets;"""
    assetNames = dbutil.getDataTable(sqlAsset)
    return jsonify(assetNames)


@api_symbol.route("/industries", methods=['GET'])
def getIndustry():
    data = dbutil.getDataTable("select industryid as id,industryname as name from industries;")
    return jsonify(data)


@api_symbol.route("/symbol/fundamental_technical/<symbols>", methods=['GET', 'POST'])
def getSymbolFundmanetalsAndTechnical(symbols):
    if request.method == "POST":
        symbols = json.loads(request.data)
    data = dbutil.getSymbolTechnicalDataAndFundamental(symbols)

    return jsonify(data)


@api_symbol.route("/symbol/technical/<symbols>", methods=['GET', 'POST'])
def getSymbolTechnical(symbols):
    if request.method == "POST":
        symbols = json.loads(request.data)
    data = dbutil.getSymbolTechnicalDataAndFundamental(symbols)

    return jsonify(data)


@api_symbol.route("/symbol/synopsis/<symbol>", methods=['POST', 'GET'])
def getSynopsis(symbol):
    sql = """select current_situation,synopsis, sign from synopsis_symbol where symbol = '{}' """.format(symbol)

    data = dbutil.getDataTable(sql)
    return jsonify(data)


@api_symbol.route("/assetSector", methods=['GET'])
def getAssetSector():
    sqlAsset = """select distinct asset_name from assets;"""
    sqlSector = """select distinct name from sectors;"""

    assetNames = dbutil.getDataTable(sqlAsset)
    sectorNames = dbutil.getDataTable(sqlSector)

    return jsonify({"assets": assetNames, "sectors": sectorNames})


@api_symbol.route("/symbol/list_type/<typeid>", methods=['POST', 'GET'])
def getSymbolListByTypeNew(typeid):
    symbols = []
    formattedTypes = typeid.split(",")
    formattedTypes = ','.join(formattedTypes)
    rows = dbutil.getDataTable("select query from list_types where typeid in ({})".format(formattedTypes))
    for row in rows:
        rowSymbols = dbutil.getDataArray(row["query"])
        symbols.extend(rowSymbols)
    return jsonify(symbols)


@api_symbol.route("/symbol/info", methods=['POST', 'GET'])
def getTickerDetails():
    tickers = ""
    detail = ""
    if request.method == 'POST':
        data = json.loads(request.data)
        tickers = data["tickers"]
        detail = data["detail"]
    else:
        tickers = request.args.get('tickers')
        detail = request.args.get("detail")

    data = dbutil.getDetailsForTickers(tickers, detail)
    if data is not None:
        return jsonify(data)
    else:
        return jsonify({})


@api_symbol.route("/symbol/live/<symbols>", methods=['POST', 'GET'])
def getLiveData(symbols):
    data = dbutil.getLiveData(utils.getSymbolListFromString(symbols))
    return jsonify(data)


@api_symbol.route("/symbol/prices", methods=['POST', 'GET'])
def getSymbolPrices():
    symbol = request.args.get('symbol')
    end_date = request.args.get('date')
    today = date.today()
    end_date = datetimeutil.getdatefromstr_format(end_date, "%Y-%m-%d")
    delta_days = today - end_date.date()
    if delta_days.days == 0:
        return getLiveData(symbol)
    else:
        start_date = end_date + timedelta(days=-5)
        data = dbutil.get_symbol_adjclose(symbol, start_date, end_date)
        if (len(data.index) >= 1):
            return jsonify(
                {symbol: {"price": data.tail(1)[symbol][0],"symbol": symbol}})  # data.tail(1).to_dict('records')
        else:
            return jsonify({})


@api_symbol.route("/symbol/technical/history/<symbols>", methods=['POST', 'GET'])
def getTechnicalHistory(symbols):
    data = dbutil.getTechnicalHistory(utils.getSymbolListFromString(symbols))
    return jsonify(data)


@api_symbol.route("/symbol/indtechnicalHistory/movAvg/<period>", methods=['POST', 'GET'])
def getMovAvgHistorical(period):
    end_date = datetime.today()
    start_date = dbutil.getStartDateFromPeriod(period)
    sql = """SELECT DATE_FORMAT(rating_date ,'%Y-%m-%d') as rating_date ,movavg50,movavg75,movavg150 FROM symbol_count_per_rating_hist
    where rating_date  >= '{}' ORDER BY rating_date ASC""".format(start_date.date())
    data = dbutil.getDataTable(sql)

    return jsonify(data)


@api_symbol.route("/symbol/technicalHistory/obos/<period>", methods=['POST', 'GET'])
def getObOsHistorical(period):
    end_date = datetime.today()
    start_date = dbutil.getStartDateFromPeriod(period)
    sql = """SELECT DATE_FORMAT(date ,'%Y-%m-%d') as date,oBPer as Overbought,oSPer as Oversold,obCount,osCount  FROM ob_os_counts WHERE  date >= '{}' order by date """.format(
        start_date.date())
    data = dbutil.getDataTable(sql)

    return jsonify(data)


@api_symbol.route("/symbol/technicalHistory/fear_greed/<period>", methods=['POST', 'GET'])
def getHistoryFearGreed(period):
    end_date = datetime.today()
    start_date = dbutil.getStartDateFromPeriod(period)
    print
    start_date
    sql = """SELECT 
    round(fear_greed,2) as fear_greed,
    round(technical,2) as technical,
    DATE_FORMAT(date,'%Y-%m-%d') as date 
    FROM history_fear_technical
    WHERE date >= '{}'
    ORDER BY date ASC;""".format(start_date.date())

    technicals = dbutil.getDataTable(sql)
    df_technical = pd.DataFrame(technicals)
    # df_spy = dbutil.getSymbolHistorical(["SPY"], period)
    # df_spy["date"] = df_spy["date"].apply(lambda row: datetimeutil.getdatestr_format(row, '%Y-%m-%d'))
    # df_merged = pd.merge(df_technical, df_spy, how='inner', left_on='date', right_on='date')
    # df_merged = df_merged.bfill().ffill()
    return df_technical.to_json(orient='records')


@api_symbol.route("/symbol/technicalHistory/sentiment/<period>", methods=['POST', 'GET'])
def getSentimentHistorical(period):
    end_date = datetime.today()
    start_date = dbutil.getStartDateFromPeriod(period)
    sql = """SELECT round(meter_score,2) as meter_score,DATE_FORMAT(date,'%Y-%m-%d') as date FROM df_spyrating
                        WHERE date >= '{}'
                ORDER BY date ASC;""".format(start_date.date())

    data = dbutil.getDataTable(sql)

    return jsonify(data)


@api_symbol.route("/symbol/technicalHistory/buySellRatio/<period>", methods=['POST', 'GET'])
def getBuySellRatioHistory(period):
    end_date = datetime.today()
    start_date = dbutil.getStartDateFromPeriod(period)
    sql = """SELECT DATE_FORMAT(rating_date,'%Y-%m-%d') as date,rating1 as StrongSell,rating5 as StrongBuy FROM symbol_count_per_rating_hist
        where rating_date >= '{}' ORDER BY rating_date ASC""".format(start_date.date())
    data = dbutil.getDataTable(sql)

    return jsonify(data)


@api_symbol.route("/global_indices/<symbols>", methods=['GET', 'POST'])
def getGlobalIndicesData(symbols):
    if request.method == "POST":
        symbols = json.loads(request.data)
    data = dbutil.getGlobalIndicesTechnicalData(symbols)

    return jsonify(data)


@api_symbol.route("/insider-transactions", methods=['GET'])
def getInsiderTransactions():
    sqlAsset = """select * from insider_transactions;"""
    transactions = dbutil.getDataTable(sqlAsset)
    return jsonify(transactions)
