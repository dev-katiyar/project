from flask import Flask
import utils
import datetimeutil
from flask import request, make_response, jsonify
import stripe_payment
import dbutil
import json
from datetime import datetime
import login
from model_portfolio_api import api_model_portfolio
from retirement_401k_api import api_401k
from login_api import api_login
from symbol_api import api_symbol
from portfolio_api import api_portfolio
from test_api import api_test
from emps import api_emp
from dividend_api import api_dividend
from technicals import api_technicals
from tpa_api import api_tpa
from options import api_options
import pytz
from algo_trading import api_algotrading
from investing import api_investing
from screen import api_screen
from rapid_api import api_rapid
from futures_data_api import api_futures
from strategy_api import api_strategy
from dynamic_columns import api_dynamic_columns
app = Flask(__name__)
app.register_blueprint(api_401k)
app.register_blueprint(api_model_portfolio)
app.register_blueprint(api_login)
app.register_blueprint(api_symbol)
app.register_blueprint(api_portfolio)
app.register_blueprint(api_test)
app.register_blueprint(api_dividend)
app.register_blueprint(api_technicals)
app.register_blueprint(api_tpa)
app.register_blueprint(api_options)
app.register_blueprint(api_algotrading)
app.register_blueprint(api_rapid)
app.register_blueprint(api_investing)
app.register_blueprint(api_emp)
app.register_blueprint(api_futures)
app.register_blueprint(api_screen)
app.register_blueprint(api_strategy)
app.register_blueprint(api_dynamic_columns)

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response


@app.route("/states", methods=['GET'])
def getStates():
    states = dbutil.getDataTable("select name as name , name as code  from us_states")
    return jsonify(states)

@app.route("/techAlerts/<symbols>", methods=['POST', 'GET'])
def getTechAlerts(symbols):
    alerts = dbutil.getTechAlerts(symbols.split(","))
    return jsonify(alerts)


@app.route("/coupouns", methods=['GET'])
def getCoupouns():
    coupons = stripe_payment.get_all_coupouns()
    return jsonify(coupons)


@app.route("/symbol/historical", methods=['POST', 'GET'])
def getHistoricalData():
    symbols = ""
    period = ""
    if request.method == 'POST':
        data = json.loads(request.data)
        symbols = data["symbols"]
        period = data["period"]
    else:
        symbols = request.args.get('symbols')
        period = request.args.get("period")

    data = dbutil.getSymbolHistoricalDiff(utils.getSymbolListFromString(symbols), period)
    if data is None:
        return jsonify([])
    return data.to_json(orient='records')


@app.route("/newsDetail/", methods=['POST', 'GET'])
def getDetailNews():
    sql = """select * from news_details 
   WHERE STR_TO_DATE(SUBSTR(substring_index(pubdate,",",-1),1,12)  , "%d %M %Y")
  BETWEEN DATE_SUB(NOW(), INTERVAL 5 DAY) AND NOW();"""

    newsData = dbutil.getDataList(sql,
                                  "source")

    return jsonify(newsData)

@app.route("/newsDetail/currentDate", methods=['POST', 'GET'])
def getCurrentDateNews():
    sql = """select source,pubDate,title,link from news_details where pubDate in
    (select pubDate from news_details where STR_TO_DATE(SUBSTR(substring_index(pubdate,",",-1),1,12)  , "%d %M %Y")
    = CURDATE()) order by pubDate desc;"""

    newsData = dbutil.getDataTable(sql)
    if len(newsData) == 0:
        sql = """select source,pubDate,title,link from news_details where pubDate in
        (select pubDate from news_details where STR_TO_DATE(SUBSTR(substring_index(pubdate,",",-1),1,12)  , "%d %M %Y")
        = CURDATE() - INTERVAL 1 DAY) order by pubDate desc;"""
        newsData = dbutil.getDataTable(sql)

    for item in newsData:
        pubDate = item['pubDate'].replace("\r", "").replace("\n", "").replace("+", "-").split("-")[0]
        pubDate = pubDate + " GMT"
        try:
            item['pubDate'] = convertToEst(pubDate)
        except Exception as e:
            print(e)
        # pubDate[17:22]
        # item.pubDate.strftime('%I:%M%p')
    return jsonify(newsData)


def convertToEst(time):
    gmt = pytz.timezone('GMT')
    eastern = pytz.timezone('US/Eastern')
    convertedDate = datetime.strptime(time, '%a, %d %b %Y %H:%M:%S GMT')
    dategmt = gmt.localize(convertedDate)
    dateeastern = dategmt.astimezone(eastern)
    d = dateeastern.strftime('%a, %d %I:%M%p')
    return d


@app.route("/notablemoves", methods=['POST', 'GET'])
def getNotableMoveSymbolByType():
    sql = """ select name,typeid,sign from notable_moves_types order by ui_order"""

    data = dbutil.getDataTable(sql)
    return jsonify(data)


@app.route("/notablemoves/<typeid>", methods=['POST', 'GET'])
def getNotableMoveSymbolDetail(typeid):
    sql = """select  ns.symbol from notable_moves_types as nt 
 join notable_moves_symbol as ns on nt.typeid=ns.type where nt.typeid ={} limit 20 """.format(typeid)

    data = dbutil.getDataArray(sql)
    return jsonify(data)


@app.route("/multicharts/<types>", methods=['POST', 'GET'])
def getMultichartsByType(types):
    formattedTypes = types.split(",")
    formattedTypes = ','.join(formattedTypes)
    sql = """select typeid as id ,description as name from list_types  where typeid in ({})""".format(formattedTypes)
    data = dbutil.getDataTable(sql)
    return jsonify(data)


@app.route("/multicharts", methods=['POST', 'GET'])
def getMulticharts():
    sql = """select typeid as id ,description as name from  list_types"""

    data = dbutil.getDataTable(sql)
    return jsonify(data)


# Returns capitalized symbol list from comma seperated values


@app.route("/sectors", methods=['GET'])
def getSectorsList():
    sql = """select name,id from sectors"""
    data = dbutil.getDataTable(sql)
    return jsonify(data)


@app.route("/etf_info", methods=['GET'])
def getEtfInfo():
    sector = dbutil.getDataTable("select name,id from etf_sector")
    asset = dbutil.getDataTable("select name,id from etf_asset")
    geography = dbutil.getDataTable("select name,id from etf_geography")
    result = {"sector": sector, "asset": asset, "geography": geography}
    return jsonify(result)


@app.route("/etf_symbols", methods=['POST'])
def getEtfSymbols():
    post_data = json.loads(request.data)

    condition = []
    asset_id = int(post_data["asset_id"])
    sector_id = int(post_data["sector_id"])
    geography_id = int(post_data["geography_id"])

    if asset_id != 0:
        condition.append("etf_asset_id ={}".format(asset_id))
    if sector_id != 0:
        condition.append("etf_sector_id ={}".format(sector_id))
    if geography_id != 0:
        condition.append("etf_geography_id ={}".format(geography_id))

    if len(condition) == 0:
        condition_query = ''
    else:
        condition_query = ' and ' + ' and '.join(condition)

    query = """SELECT technicals_symbol.symbol as symbol
         FROM technicals_symbol LEFT JOIN list_symbol
         ON list_symbol.symbol= technicals_symbol.Symbol LEFT JOIN live_symbol 
         ON live_symbol.symbol= technicals_symbol.Symbol
         Left Join stats_latest ON stats_latest.symbol= technicals_symbol.Symbol
         where list_symbol.assetid in (24,22,25) and list_symbol.isactive =1  and change_pct !=0 and change_pct is not null and abs((last - price_Monthly)/price_Monthly) < 3 {}""".format(
        condition_query)

    # sql = "select symbol from list_symbol where assetid= 24 and {}  {} ".format(condition_query)

    symbols = dbutil.getDataArray(query)
    return jsonify(symbols)


@app.route("/industries", methods=['GET'])
def getIndustryList():
    sql = """select industryname as name,industryid as id from industries"""
    data = dbutil.getDataTable(sql)
    return jsonify(data)


@app.route("/sectors/<symbols>", methods=['POST', 'GET'])
def getSectors(symbols):
    formattedSymbols = map(lambda x: "'" + x + "'", symbols.split(","))
    formattedSymbols = ','.join(formattedSymbols)
    sql = """select s.name,count(*) as count from list_symbol ls 
  join sectors s on ls.sectorid = s.id
  where ls.symbol in ({})
  group by s.name """.format(formattedSymbols)
    data = dbutil.getDataTable(sql)
    total = sum(item["count"] for item in data)

    for item in data:
        percentage = round((100 * item["count"]) / total, 2)
        item.update({"percentage": percentage})

    return jsonify(data)


@app.route("/lookup", methods=['POST', 'GET'])
def getTickerLook():
    identifier = request.args.get('t')
    asset_type = request.args.get('e')

    searchLetter = identifier.replace(" ", "").replace(".", "").replace("-", "") + "%"
    filter_query = ""
    if asset_type is not None:
        filter_query = "and a.asset_type ='{}'".format(asset_type)

    sql = """select  symbol , companyname as name,ifnull(exchange,'') as exchange ,
      ifnull(asset_type,'') as asset_type 
        from list_symbol  l
        left join assets a on l.assetid = a.asset_id
        where replace(replace(replace(symbol,' ',''),'-',''),'.','') LIKE '{}' and isactive =1  {}
        
        union
        
        select  symbol , companyname as name ,ifnull(exchange,'') as exchange,
        ifnull(asset_type,'') as asset_type
        from list_symbol l
        left join assets a on l.assetid = a.asset_id
        
        where  replace(companyname,' ','') like '{}'and isactive =1  {}
        order by symbol limit 50;""".format(
        searchLetter, filter_query, searchLetter, filter_query)
    # left join assets a on l.assetid = a.asset_id

    data = dbutil.getDataTable(sql)
    formatted_data = dbutil.convertToSeperated(data, ["symbol", "name", "exchange", "asset_type"])
    response = {"payload": {
        "symbols": formatted_data
    }}
    return jsonify(response)


@app.route("/search/<searchLetter>", methods=['POST', 'GET'])
def getSearchResults(searchLetter):
    searchLetter = searchLetter.replace(" ", "").replace(".", "").replace("-", "") + "%"

    sql = """select  symbol , companyname as name,ifnull(assetId,1000) as assetId
        from list_symbol where replace(replace(replace(symbol,' ',''),'-',''),'.','')
         LIKE '{}' and isactive =1   
        
        union
        
        select  symbol , companyname as name ,ifnull(assetId,1000) as assetId
        from list_symbol where  replace(companyname,' ','') like '{}'and isactive =1  
        order by assetid ,symbol limit 40;""".format(
        searchLetter, searchLetter)

    data = dbutil.getDataTable(sql)
    return jsonify(data)


@app.route("/sector/yearly/<symbol>", methods=['POST', 'GET'])
def getSectorPerfYearly(symbol):
    sql = """select ls.symbol as symbol
            from list_symbol ls
            left join live_symbol l on l.symbol =ls.symbol
            left join sectors s on s.id=ls.sectorid
            left join technicals_symbol t on ls.symbol= t.symbol
            where s.symbol  = '{}' and  (l.last-t.price_Yearly)/(t.price_Yearly) <  500 and l.last > 10
            order by (l.last-t.price_Yearly)/(t.price_Yearly)  desc limit 10;
            
            """.format(symbol)

    data = dbutil.getDataArray(sql, "symbol")

    return jsonify(data)


@app.route("/industry/yearly/<symbol>", methods=['POST', 'GET'])
def getIndustryPerfYearly(symbol):
    sql = """select ls.symbol from sector_industry_symbol si
join list_symbol ls on ls.industryid=si.industryid
left join live_symbol l on l.symbol =ls.symbol
left join technicals_symbol t on ls.symbol= t.symbol
 where si.symbol  = '{}' and  (l.last-t.price_Yearly)/(t.price_Yearly) <  500 and l.last > 10
 order by (l.last-t.price_Yearly)/(t.price_Yearly)  desc limit 10;""".format(symbol)

    data = dbutil.getDataArray(sql, "symbol")

    return jsonify(data)


@app.route('/sector/industryMapping', methods=['GET'])
def getSectorIndustryMapping():
    sqlSector = """select s.symbol,s.short_name as name,s.id as sectorid , t.rating from sectors  s
    join technicals_symbol t on t.symbol = s.symbol
    where s.symbol is not null and s.id not in (20,21)"""
    sqlIndustry = """select si.symbol,si.sectorid,i.industryname,t.rating from sector_industry_symbol si 
                   join industries i on si.industryid = i.industryid
                   join technicals_symbol t on t.symbol = si.symbol"""
    sectorData = dbutil.getDataTable(sqlSector)
    industryData = dbutil.getDataList(sqlIndustry, "sectorid")
    for sectorItem in sectorData:
        sectorId = sectorItem["sectorid"]
        if sectorId in industryData:
            sectorItem["industryData"] = industryData[sectorId]

    return jsonify(sectorData)


@app.route('/heatmap/<type>', methods=['GET'])
def getHeatMapByType(type):
    sqlSector = """select sp.symbol,s.name as name,live.change_pct
                  from spy_symbol sp
                  join list_symbol l on sp.symbol = l.symbol
                  join sectors s on l.sectorid = s.id
                  join live_symbol live
                  on live.symbol = sp.symbol and change_pct is not null """

    result = []
    sectorData = dbutil.getDataList(sqlSector, "name")
    for sector, data in sectorData.iteritems():
        symbolList = []
        data.sort(lambda x, y: cmp(float(x['change_pct']), float(y['change_pct'])))
        for symbolData in data[-10:]:
            symbolList.append(symbolData["symbol"])
        for symbolData in data[0:10]:
            symbolList.append(symbolData["symbol"])

        result.append({"sector": sector, "data": symbolList})

    return jsonify(result)


@app.route('/spy/technical', methods=['GET'])
def getSpyTechnical():
    sqlSector = """select * from spy_technical"""
    data = dbutil.getOneRow(sqlSector)
    return jsonify(data)


@app.route("/scan/filters", methods=['GET'])
def getScanFilters():
    data = dbutil.getScanFilters()
    return jsonify(data)


@app.route("/peer/<symbol>", methods=['GET'])
def getPeerSymbols(symbol):
    peerSymbols = dbutil.getPeers(symbol)
    peerSymbols.append(symbol)
    return jsonify(peerSymbols)


@app.route("/scan/symbols", methods=['POST'])
def getScanSymbols():
    scan_ids = json.loads(request.data)
    scan_ids = map(lambda x: "'" + x + "'", scan_ids.split(","))
    scan_ids = ','.join(scan_ids)
    sql = """select s.Condition as filters from scan_filter s where id in ({})""".format(scan_ids)

    conditionStatements = dbutil.getDataArray(sql, "filters")
    conditionStatements = " and ".join(conditionStatements)
    query = """SELECT technicals_symbol.symbol as symbol
         FROM technicals_symbol LEFT JOIN list_symbol
         ON list_symbol.symbol= technicals_symbol.Symbol LEFT JOIN live_symbol 
         ON live_symbol.symbol= technicals_symbol.Symbol
         Left Join stats_latest ON stats_latest.symbol= technicals_symbol.Symbol
         where ({}) and list_symbol.isactive =1  and 
         change_pct !=0 and change_pct is not null 
         and abs((last - price_Monthly)/price_Monthly) < 3 
         order by CAST(last AS DECIMAL(10,6)) desc""".format(
        conditionStatements)
    symbols = dbutil.getDataArray(query, "symbol")
    return jsonify(symbols)


@app.route('/analyst/<symbol>', methods=['GET'])
def getAnalyst(symbol):
    symbol = symbol.upper()
    result = {"error": ""}
    data = dbutil.get_data_by_collection("analyst_rating", {"symbol": symbol})
    if data is not None:
        analyst_rating = data["rating"]
        result["analyst_rating"] = analyst_rating
    else:
        result["error"] = "No data for symbol {}".format(symbol)
    return jsonify(result)


@app.route("/dashboard/params/<date>", methods=['GET'])
def getDashboardParams(date):
    date = date[0:10]
    sql = """select date,fear_greed ,technical as technical 
    from history_fear_technical where date >='{}'""".format(date)
    data = dbutil.getDataTable(sql)
    for item in data:
        item["date"] = datetimeutil.getdatestr(item["date"])
    return jsonify(data)


@app.route("/dashboard/params", methods=['POST'])
def saveDashBoardParams():
    params_dict = json.loads(request.data)
    date = params_dict["date"][0:10]
    sql_check = "select count(*) as count from history_fear_technical where date ='{}'".format(date)
    count = dbutil.getOneRow(sql_check, "count")
    if count == 0:
        sql = """insert into history_fear_technical(date,fear_greed,technical)
               values('{}',{},{})""".format(date, params_dict["fear_greed"], params_dict["technical"])
        dbutil.execute_single_query(sql)
        return jsonify({"message": "Saved Data"})
    else:
        sql = """update  history_fear_technical 
        set fear_greed={},
        technical= {}
        where date ='{}'""".format(params_dict["fear_greed"], params_dict["technical"], date)
        dbutil.execute_single_query(sql)
        return jsonify({"message": "Updated Data"})


@app.route("/technical_market", methods=['GET'])
def getTechnicalMarket():
    sql = "select * from technical_market;"

    marketData = dbutil.getDataTable(sql)
    return jsonify(marketData)


def checkIfUserActive(request):
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        sqlIsPaid = "select ispaid from users where userid ={}".format(userId)
        isPaid = dbutil.getOneRow(sqlIsPaid, "ispaid")
        if isPaid != 1:
            isPaid = stripe_payment.isUserActive(userId)
            if isPaid != 1:
                responseObject = {
                    'status': 'fail',
                    'message': 'Provide a valid auth token.'
                }
                return jsonify(responseObject)


@app.route("/dashboard_commentary_data/<size>", methods=['GET'])
def getDashboardCommentaryData(size):
    checkIfUserActive(request)
    sqlCommentary = "select * from dashboard_commentary limit {};".format(size)
    dashboard_commentary = dbutil.getDataTable(sqlCommentary)

    result = {"dashboard": dashboard_commentary}
    return jsonify(result)


@app.route("/dashboard_alert_data/<size>", methods=['GET'])
def getDashboardAlertData(size):
    checkIfUserActive(request)
    sqlAlert = "select * from dashboard_portfolio_alerts limit {};".format(size)
    portfolio_alert = dbutil.getDataTable(sqlAlert)

    result = {"dashboard": portfolio_alert}
    return jsonify(result)


@app.route("/dashboard_videos_data/<size>", methods=['GET'])
def getDashboardVideosData(size):
    checkIfUserActive(request)
    sqlVideos = "select * from dashboard_videos limit {};".format(size)
    dashboard_videos = dbutil.getDataTable(sqlVideos)

    result = {"dashboard": dashboard_videos}
    return jsonify(result)


@app.route("/dashboard_daily_data/<size>", methods=['GET'])
def getDashboardDailyData(size):
    checkIfUserActive(request)
    sqlDaily = "select * from dashboard_daily limit {};".format(size)
    dashboard_daily = dbutil.getDataTable(sqlDaily)

    result = {"dashboard": dashboard_daily}
    return jsonify(result)


@app.route("/dashboard_chart_data/<size>", methods=['GET'])
def getDashboardChartData(size):
    sqlChart = "select * from dashboard_chart limit {};".format(size)
    dashboard_chart = dbutil.getDataTable(sqlChart)

    result = {"dashboard": dashboard_chart}
    return jsonify(result)


@app.route("/users_symbol_alerts", methods=['POST'])
def saveUserSymbolAlerts():
    token = login.checkToken(request)
    query = ""

    if token["status"] == "success":
        userId = token["data"]["user_id"]
        post_data = json.loads(request.data)
        symbol = post_data["symbol"]
        high_target = post_data["high_target"] or 'null'
        low_target = post_data["low_target"] or 'null'
        daily_high = post_data["daily_high"] or 'null'
        deleted = post_data["deleted"] or False
        daily_low = post_data["daily_low"] or 'null'
        insert_query = """ insert into symbol_alerts(user_id,symbol,high_target,low_target,daily_high,daily_low,deleted)
            values ({},'{}',{},{},{},{},{})
            """.format(userId, symbol, high_target, low_target, daily_high, daily_low, deleted)

        count_query = """
            select count(*) as count from symbol_alerts where symbol ='{}' and user_id ={}
            """.format(symbol, userId)
        alert_count = dbutil.getOneRow(count_query, "count")
        if alert_count > 0:
            update_query = """ update  symbol_alerts
                set high_target = {},
                low_target ={},
                daily_high = {},
                daily_low = {},
                deleted = {}
                where symbol ='{}' and user_id ={}
                """.format(high_target, low_target, daily_high, daily_low, deleted, symbol, userId)
            updated_count = dbutil.execute_single_query(update_query)
        else:
            dbutil.execute_single_query(insert_query)

        return jsonify({"staus": "ok"})

    else:
        return make_response(jsonify(token)), 401


@app.route("/users_symbol_alerts", methods=['GET'])
def getUserSymbolAlerts():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        query = """select * from (
        select distinct symbol ,user_id from symbol_alerts where user_id = {}
        union
        select distinct symbol ,m.user_id from transactions t join model_portfolio m 
        on m.portfolioid = t.portfolioid where m.user_id = {}
        union
        select distinct ps.symbol ,user_id
                    from portfolio p 
                    join portfolio_symbols ps on p.portfolio_id= ps.portfolio_id
                    where p.user_id = {}
        union
        select distinct symbol,userid  from watchlist_details wd join 
           watchlist_compostion wc on wc.watchlist_id = wd.watchlist_id where userid = {}
           ) t1 left join symbol_alerts sa on t1.symbol = sa.symbol and sa.user_id = t1.user_id where
           sa.user_id is null or sa.deleted !=1
           order by id desc;
        """.format(userId, userId, userId, userId)
        data = dbutil.getDataTable(query)
        return jsonify(data)
    else:
        return make_response(jsonify(token)), 401


@app.route("/users_symbol_alerts_history", methods=['GET'])
def getUserHistoricalSymbolAlertsMet():
    token = login.checkToken(request)
    if token["status"] == "success":
        userId = token["data"]["user_id"]
        query = """select sat.type as type ,value as target, h.symbol,
            time as date, last ,price_change , change_pct
            from symbol_alerts_history h
            join symbol_alerts sa on h.symbol = sa.symbol and sa.user_id = h.user_id
            join symbol_alerts_types sat on h.alert_type = sat.id
            where h.user_id ={} order by time desc
                """.format(userId)
        data = dbutil.getDataTable(query)
        return jsonify(data)
    else:
        return make_response(jsonify(token)), 401


@app.route("/backtest/stub", methods=['GET'])
def getBacktestData():
    response = {"portfolioName": ["Portfolio1", "Portfolio2", "Portfolio3", "S&P500"],
                "performance":
                    [{"name": "Portfolio1", "initialBalance": 10000, "finalBalance": 7764999, "CAGR": 49.68,
                      "stdev": 53.80,
                      "bestYear": 361.97, "worstYear": -51.95, "maxDrawdown": -71.96,
                      "sharpeRatio": 0.99, "sortinoRatio": 1.94, "mktCorrelation": 0.30},

                     {"name": "Portfolio2", "initialBalance": 10000, "finalBalance": 2207506, "CAGR": 38.69,
                      "stdev": 33.40,
                      "bestYear": 201.36, "worstYear": -56.91, "maxDrawdown": -56.91,
                      "sharpeRatio": 1.12, "sortinoRatio": 2.00, "mktCorrelation": 0.50},

                     {"name": "Portfolio3", "initialBalance": 10000, "finalBalance": 7764999, "CAGR": 45.14,
                      "stdev": 59.74,
                      "bestYear": 396.73, "worstYear": -60.56, "maxDrawdown": -79.90,
                      "sharpeRatio": 0.90, "sortinoRatio": 1.69, "mktCorrelation": 0.27},

                     {"name": "S&P500", "initialBalance": 10000, "finalBalance": 8764999, "CAGR": 54.14,
                      "stdev": 69.74,
                      "bestYear": 496.73, "worstYear": -30.56, "maxDrawdown": -49.90,
                      "sharpeRatio": 1.90, "sortinoRatio": 2.69, "mktCorrelation": 1.27}
                     ],
                "yearly":
                    [{"year": 2005, "portfolio1": 123.26, "portfolio2": 115.19, "portfolio3": 91.96, "S&P500": 101.96},
                     {"year": 2006, "portfolio1": 13.26, "portfolio2": 18.19, "portfolio3": -4.96, "S&P500": 90.96},
                     {"year": 2007, "portfolio1": 133.26, "portfolio2": 44.19, "portfolio3": 2.96, "S&P500": 80.16},
                     {"year": 2008, "portfolio1": -56.26, "portfolio2": -53.19, "portfolio3": 12.96, "S&P500": 40.86},
                     {"year": 2009, "portfolio1": 146.26, "portfolio2": 93.32, "portfolio3": 84.96, "S&P500": 86.90},
                     {"year": 2010, "portfolio1": 53.06, "portfolio2": -4.19, "portfolio3": 291.96, "S&P500": 100.19}],
                "daily":
                    [{"date": "Jan 02, 2005", "portfolio1": 1000.0, "portfolio2": 1000.0, "S&P500": 1001.0},
                     {"date": "Jan 03, 2016", "portfolio1": 1005, "portfolio2": 1010, "S&P500": 1011.0},
                     {"date": "Jan 02, 2007", "portfolio1": 1021, "portfolio2": 1054, "S&P500": 1021.0},
                     {"date": "Jan 03, 2008", "portfolio1": 1032, "portfolio2": 1065, "S&P500": 1045.10},
                     {"date": "Jan 02, 2009", "portfolio1": 1076, "portfolio2": 1079, "S&P500": 1087.0},
                     {"date": "Jan 03, 2010", "portfolio1": 2000, "portfolio2": 2010, "S&P500": 2011}]

                }
    return jsonify(response)


@app.route("/performance/stub", methods=['GET'])
def getPerformanceData():
    response = {"daily":
                    [{"name": "AAPL", "day1": 1.04, "day5": -6.57, "week1": -2.54,
                      "day10": -1.53, "day15": -2.59},
                     {"name": "Technology", "day1": 1.03, "day5": -6.31, "week1": -2.51,
                      "day10": -1.21, "day15": -2.49},
                     {"name": "S&P", "day1": 0.08, "day5": -3.31, "week1": -3.51,
                      "day10": -0.21, "day15": -4.49}
                     ],

                "yearly":
                    [{"name": "AAPL", "ytd": 27.13, "year1": -2.47, "year2": 24.30,
                      "year3": 17.38, "year4": 24.66, "year5": 36.01},
                     {"name": "Technology", "ytd": 7.13, "year1": -12.47, "year2": 4.30,
                      "year3": 7.38, "year4": 2.66, "year5": 6.01},
                     {"name": "S&P", "ytd": 2.13, "year1": -3.47, "year2": 2.30,
                      "year3": 1.38, "year4": 4.66, "year5": 3.01}
                     ],
                "quaterly":
                    [{"name": "AAPL", "quater1": 18.54, "quater2": 10.42, "quater3": 14.19,
                      "quater4": 10.71},
                     {"name": "Technology", "quater1": 27.13, "quater2": 24.81, "quater3": 8.01,
                      "quater4": 28.39},
                     {"name": "S&P", "quater1": 27.13, "quater2": 8.52, "quater3": 14.19,
                      "quater4": 17.38}
                     ]

                }
    return jsonify(response)


if __name__ == "__main__":
    app.run()
