/**
 *	8.6.0
 *	Generation date: 2022-03-28T16:28:54.145Z
 *	Client name: real investment advice
 *	Package Type: Technical Analysis e98f22c
 *	License type: annual
 *	Expiration date: "2022/08/19"
 *	Domain lock: ["127.0.0.1","localhost","realinvestmentadvice.com","riapro.net","18.188.218.82","simplevisor.com","3.138.80.45"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ } from "../../js/chartiq.js";
import "./signaliq.js";

const cssReady = new Promise((resolve) => {
	if (
		typeof define === "undefined" &&
		typeof module === "object" &&
		typeof require === "function"
	) {
		// webpack 4
		resolve(require("./signaliqDialog.css"));
	} else if (typeof define === "function" && define.amd) {
		define(["./signaliqDialog.css"], resolve);
	} else if (import.meta.webpack) {
		// webpack 5
		import(/* webpackMode: "eager" */ "./signaliqDialog.css").then(resolve);
	} else if (typeof window !== "undefined") {
		// no webpack
		CIQ.SignalIQ.stylesheets.push({
			url: new URL("./signaliqDialog.css", import.meta.url).href,
			callback: resolve
		});
	}
}).then((m) => CIQ.addInternalStylesheet(m, "signaliqDialog")); // a framework, such as Angular, may require style addition

if (CIQ.UI) {
	CIQ.UI.StudyEdit.prototype.editPanel = function (params, editStudy) {
		const { stx, config } = this.context;
		params.context = this.context;
		// Make sure we don't open the dialog in the context menu position
		params.x = null;
		params.y = null;

		const { channelWrite } = CIQ.UI.BaseComponent.prototype;

		const name = !editStudy && params.sd.signalData ? "signaliq" : "study";

		if (config) {
			const channel = (config.channels || {}).dialog || "channel.dialog";
			channelWrite(channel, { type: name, params }, stx);
		} else {
			stx.container.ownerDocument
				.querySelector("cq-" + name + "-dialog")
				.open(params);
		}
	};

	/**
	 * SignalIQ Dialog web component `<cq-signaliq-dialog>`.
	 *
	 * Displays a dialog so signal studies can be entered into the system through the UI.
	 *
	 * **Requires [SignalIQ]{@link CIQ.SignalIQ} plugin.**
	 *
	 * @namespace WebComponents.cq-signaliq-dialog
	 * @since 8.6.0
	 *
	 * @example
	 * <h4 class="title">New Signal</h4>
	 * <cq-close></cq-close>
	 * <div cq-study-edit-dialog-div>
	 * 	<form id="study-signal" class="study-signal">
	 * 		<h2 cq-add-only>Choose a Study:</h2>
	 * 		<div class="study-select-container"></div>
	 * 		<div cq-tooltip-activator class="ciq-edit-study" stxtap="editStudy()">
	 * 			&nbsp;
	 * 			<cq-tooltip>Edit Study</cq-tooltip>
	 * 		</div>
	 * 		<h2>Define Conditions:</h2>
	 * 		<div class="cq-study-signal-conditions"></div>
	 * 		<hr/>
	 * 		<div class="notification-type-container"></div>
	 * 		<div class="ciq-marker-container">
	 * 			<h2>Choose an appearance:</h2>
	 * 			<div class="ciq-marker-settings">
	 * 				<div class="ciq-marker-preview">
	 * 					<div class="stx-marker signal">
	 * 						<div class="stx-visual"></div>
	 * 						<div class="stx-marker-content"></div>
	 * 					</div>
	 * 				</div>
	 * 				<div class="ciq-marker-options"></div>
	 * 			</div>
	 * 		</div>
	 * 		<h2>Description</h2>
	 * 		<textarea name="signal-description" type="text" placeholder="Description will appear in an infobox when the signal is clicked."></textarea>
	 * 		<hr/>
	 * 		<div class="clearfix"></div>
	 * 		<div class="ciq-misc-settings">
	 * 			<input name="signal-name" type="text" value="" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" placeholder="Enter a Name" />
	 * 			<div class="ciq-btn ciq-btn-save" stxtap="save()">Save</div>
	 * 			<h2 class="info-message"><h2>
	 * 		</div>
	 * 	</form>
	 * 	<template cq-study-menu>
	 * 		<cq-menu class="ciq-select">
	 * 			<cq-selected></cq-selected>
	 * 			<cq-menu-dropdown cq-lift>
	 * 				<cq-study-filter cq-filter-min="15"></cq-study-filter>
	 * 				<cq-study-items></cq-study-items>
	 * 			</cq-menu-dropdown>
	 * 		</cq-menu>
	 * 	</template>
	 * 	<template cq-menu>
	 * 		<cq-menu class="ciq-select">
	 * 			<cq-selected></cq-selected>
	 * 			<cq-menu-dropdown cq-lift></cq-menu-dropdown>
	 * 		</cq-menu>
	 * 	</template>
	 * </div>
	 */
	class SignalIQDialog extends CIQ.UI.DialogContentTag {
		constructor() {
			super();
			this.activeStudy = null;
			this.editMode = false;
		}

		adoptedCallback() {
			super.adoptedCallback();
			CIQ.UI.flattenInheritance(this, SignalIQDialog);
		}

		/**
		 * Push a new empty array to the `signalParams.conditions` and re-render the
		 * condition options UI.
		 *
		 * @memberOf WebComponents.cq-study-signaliq--dialog#
		 * @alias addCondition
		 * @since 8.6.0
		 */
		addCondition() {
			this.signalParams.conditions.push([]);
			this.renderConditionOptions();
		}

		/**
		 * Callback function for the study select menu. Adds the selected
		 * study to the chart.
		 *
		 * @param {HTMLElement} node Element selected from the menu.
		 * @param {string} name Name of the study to add.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias addStudy
		 * @since 8.6.0
		 */
		addStudy(node, name) {
			this.removeActiveStudy();
			this.activeStudy = CIQ.Studies.addStudy(this.stx, name);
			if (this.studyMenu) {
				const inputValue = this.studyMenu.find("cq-selected");
				inputValue.text(this.stx.translateIf(this.activeStudy.name));
			}
			this.renderConditionOptions();
			if (this.activeStudy.parameters.interactiveAdd) {
				this.settingInteractive = true;
				this.context.uiManager.closeMenu();
				this.settingInteractive = false;
				this.activeStudy.parameters.interactiveAddCB = () => {
					delete this.activeStudy.parameters.interactiveAddCB;
					this.open({ sd: this.activeStudy });
					this.stx.findHighlights(null, true);
				};
			}
		}

		/**
		 * Closes the dialog.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias close
		 * @since 8.6.0
		 */
		close() {
			this.reset();
			super.close();
		}

		/**
		 * Closes any lifts or popups for the node.
		 *
		 * @param {HTMLElement} node Element to collapse.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias collapse
		 * @since 8.6.0
		 */
		collapse(node) {
			node.querySelectorAll("cq-menu").forEach((el) => {
				el.close();
			});
			node.querySelectorAll("cq-swatch").forEach((el) => {
				if (el.colorPicker) el.colorPicker.close();
			});
		}

		/**
		 * Invoke the Study Edit dialog for the currently active study
		 *
		 * @param {Object} activator
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias editStudy
		 * @since 8.6.0
		 */
		editStudy(activator) {
			if (!this.activeStudy) return;
			activator.e.stopPropagation();
			this.collapse(this);
			var studyEdit = this.context.getAdvertised("StudyEdit");
			var params = {
				stx: this.stx,
				sd: this.activeStudy,
				inputs: this.activeStudy.inputs,
				outputs: this.activeStudy.outputs,
				parameters: this.activeStudy.parameters,
				axisSelect: false,
				panelSelect: false,
				opener: this.closest("cq-dialog")
			};
			studyEdit.editPanel(params, true);
		}

		/**
		 * Hides the dialog and resets local signal properties if
		 * not in the middle of an interactive add operation.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias hide
		 * @since 8.6.0
		 */
		hide() {
			this.collapse(this);
			if (!this.settingInteractive) this.reset();
		}

		/**
		 * Adds local property containing dropdown menu options.
		 * Adds form element event handlers.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias init
		 * @since 8.6.0
		 */
		init() {
			this.formElements = {
				name: this.querySelector("[name=signal-name]"),
				description: this.querySelector("[name=signal-description]")
			};

			this.selectOptions = {
				operator: [
					[">", "Is Greater Than"],
					["<", "Is Less Than"],
					["=", "Is Equal To"],
					["x", "Crosses"],
					["x+", "Crosses Above"],
					["x-", "Crosses Below"],
					[">p", "Increases"],
					["<p", "Decreases"],
					["=p", "Does Not Change"]
				],
				shape: [
					["circle", "Circle"],
					["square", "Square"],
					["diamond", "Diamond"]
				],
				size: [
					["S", "Small"],
					["M", "Medium"],
					["L", "Large"]
				],
				position: [
					["above_candle", "Above Candle"],
					["below_candle", "Below Candle"],
					["on_candle", "On Candle"]
				]
			};

			const cb = () => this.updateFormValues(true);

			Object.values(this.formElements).forEach((element) => {
				element.addEventListener("change", cb);
			});

			this.formElements.name.addEventListener("keyup", cb);

			this.initialized = true;
		}

		/**
		 * Create a cq-menu form element and return it. The created element
		 * is not attached to the DOM.
		 *
		 * @param {string} name Name of the form element.
		 * @param {string} currentValue Value to select by default.
		 * @param {Array} fields A one dimensional array of values or 2 dimensional array of name/value pairs.
		 * @param {string} cb Stringified callback function template, with $val to be replaced,
		 * 						and called when a value is selected.
		 * @return {HTMLElement} cq-menu element
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias makeMenu
		 * @since 8.6.0
		 */
		makeMenu(name, currentValue, fields, cb) {
			let currentValueLabel = "";
			if (!isNaN(currentValue))
				currentValueLabel = this.stx.translateIf("Value");
			const menu = CIQ.UI.makeFromTemplate(this.menuTemplate);
			menu[0].classList.add(name);
			const cqMenu = menu.find("cq-menu-dropdown"); // scrollable in menu.
			for (let field in fields) {
				let value, label;
				if (Array.isArray(fields[field])) {
					[value, label] = fields[field];
				} else {
					value = label = fields[field];
				}
				if (!currentValueLabel && currentValue == value)
					currentValueLabel = this.stx.translateIf(label);
				let item = document.createElement("cq-item");
				item.innerText = label;
				item.setAttribute("stxtap", cb.replace("$val", "'" + value + "'")); // must call StudyDialog because the item is "lifted" and so doesn't know its parent
				cqMenu.append(item);
				item.cqMenuWrapper = cqMenu.parents("cq-menu")[0];
				item.setAttribute("name", name);
				item.setAttribute("value", field);
				item.context = this.context;
			}
			const inputValue = menu.find("cq-selected");
			inputValue.text(currentValueLabel || "Select...");
			return menu[0];
		}

		/**
		 * Create a cq-menu form element with all available studies and inject a
		 * search field in the menu header to filter options. The menu is automatically
		 * attached to a local element with class `study-select-container`.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias makeStudyMenu
		 * @since 8.6.0
		 */
		makeStudyMenu() {
			const studySelectContainer = this.querySelector(
				".study-select-container"
			);
			// Wipe the study menu block clean
			while (studySelectContainer.firstChild) {
				studySelectContainer.lastChild.remove();
			}
			if (this.editMode) {
				studySelectContainer.innerText = this.stx.translateIf(
					this.activeStudy.name
				);
				return;
			}
			const studyDefs = CIQ.Studies.studyLibrary;
			const menu = CIQ.UI.makeFromTemplate(this.studyMenuTemplate);
			const cqMenu = menu.find("cq-menu-dropdown"); // scrollable in menu.
			const itemContainer = cqMenu[0].querySelector("cq-study-items");
			const filterContainer = cqMenu[0].querySelector("cq-study-filter");

			const input = document.createElement("input");
			input.type = "search";
			input.placeholder = "Search";
			filterContainer.appendChild(input);

			let previousValue = "";

			const updateListVisibility = ({ target: { value } }) => {
				const re = new RegExp(value, "i");
				const qsa = this.qsa;

				qsa("cq-item", itemContainer).forEach((el) => {
					const visibilityAction =
						value && !re.test(el.textContent) ? "add" : "remove";
					el.classList[visibilityAction]("item-hidden");
					if (previousValue !== value) {
						previousValue = value;
						this.removeFocused.apply(itemContainer);
						qsa("cq-keyboard-selected-highlight").forEach((highlightEl) => {
							highlightEl.classList.add("disabled");
						});
						input.focus();
					}
				});
			};
			input.addEventListener("input", updateListVisibility);
			input.addEventListener("keyup", updateListVisibility);
			input.addEventListener("pointerdown", (e) => e.stopPropagation());

			Object.keys(studyDefs)
				.sort(function (lhs, rhs) {
					var lsd = CIQ.Studies.studyLibrary[lhs];
					var rsd = CIQ.Studies.studyLibrary[rhs];
					if (lsd.name < rsd.name) return -1;
					if (lsd.name > rsd.name) return 1;
					return 0;
				})
				.filter(
					(study) =>
						!this.stx.signalIQ.allowedStudies.length ||
						this.stx.signalIQ.allowedStudies.includes(study)
				)
				.forEach((study) => {
					let item = document.createElement("cq-item");
					item.innerText = studyDefs[study].name;
					item.setAttribute(
						"stxtap",
						"SignalIQDialog.addStudy('" + study + "')"
					); // must call StudyDialog because the item is "lifted" and so doesn't know its parent
					itemContainer.append(item);
					item.cqMenuWrapper = cqMenu.parents("cq-menu")[0];
					item.setAttribute("name", "study");
					item.setAttribute("value", study);
					item.context = this.context;
				});
			const inputValue = menu.find("cq-selected");
			if (this.activeStudy)
				inputValue.text(this.stx.translateIf(this.activeStudy.name));
			else inputValue.text(this.stx.translateIf("Select..."));
			this.studyMenu = menu;
			if (
				itemContainer.children.length <
				(filterContainer.getAttribute("cq-filter-min") || 15)
			)
				filterContainer.remove();
			studySelectContainer.appendChild(menu[0]);
		}

		/**
		 * Called when the dialog is invoked. Automatically sets up local properties
		 * for either adding or editing a study signal.
		 *
		 * @param {object} params The parameter object.
		 * @param {CIQ.Studies.StudyDescriptor} params.sd The study descriptor.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias open
		 * @since 8.6.0
		 */
		open(params) {
			super.open(params);
			this.addDefaultMarkup();
			if (!this.initialized) this.init();

			this.validateSignalParams();

			this.menuTemplate = this.querySelector("template[cq-menu]");
			this.studyMenuTemplate = this.querySelector("template[cq-study-menu]");
			const titleElem = this.querySelector("h4.title");

			if (params.context) {
				this.context = params.context;
				this.stx = params.context.stx;
				this.context.advertiseAs(this, "SignalIQDialog");
				this.layoutListener = this.stx.addEventListener("layout", () => {
					if (this.activeStudy) {
						this.signalParams.conditions.forEach((condition) => {
							condition[0] = condition[0].replace(
								this.signalParams.studyName,
								this.activeStudy.name
							);
							if (typeof condition[2] === "string")
								condition[2] = condition[2].replace(
									this.signalParams.studyName,
									this.activeStudy.name
								);
						});
						this.makeStudyMenu();
						this.renderConditionOptions();
					}
				});
			}

			if (params.sd && params.sd.signalData) {
				// Edit an existing study signal
				this.editMode = true;
				titleElem.innerText = titleElem.innerText.replace("New", "Edit");
				this.querySelectorAll("[cq-add-only]").forEach(
					(el) => (el.hidden = true)
				);
				this.activeStudy = params.sd;
				// Populate signalParams with existing values
				this.signalParams = {
					name: params.sd.signalData.name,
					description: params.sd.signalData.description,
					label: params.sd.signalData.label,
					position: params.sd.signalData.position,
					shape: params.sd.signalData.shape,
					size: params.sd.signalData.size,
					joiner: params.sd.signalData.joiner,
					reveal: params.sd.signalData.reveal,
					notificationType: params.sd.signalData.notificationType,
					conditions: params.sd.signalData.conditions.map((condition) =>
						condition.slice()
					)
				};
			} else {
				// Create a new study signal
				this.editMode = false;
				titleElem.innerText = titleElem.innerText.replace("Edit", "New");
				this.querySelectorAll("[cq-add-only]").forEach(
					(el) => (el.hidden = false)
				);
				// Initialize a new signalParams object
				this.signalParams = {
					name: "",
					description: "",
					label: "X",
					position: "above_candle",
					shape: "circle",
					size: "M",
					joiner: "&",
					conditions: [],
					studyName: ""
				};
			}
			if (this.activeStudy && !this.stx.layout.studies[this.activeStudy.name])
				this.activeStudy = null;

			this.updateFormValues();
			this.renderNotificationTypes();
			this.renderMarkerOptions();
			this.renderConditionOptions();
			this.makeStudyMenu();
		}

		/**
		 * Remove the active study from the chart.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias removeActiveStudy
		 * @since 8.6.0
		 */
		removeActiveStudy() {
			if (this.activeStudy) {
				CIQ.Studies.removeStudy(this.stx, this.activeStudy);
				this.activeStudy = null;
				this.signalParams.studyName = "";
				this.signalParams.conditions = [];
			}
		}

		/**
		 * Update form controls related to marker condition options based on values in
		 * `signalParams.conditions` array.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias renderConditionOptions
		 * @since 8.6.0
		 */
		renderConditionOptions() {
			// don't re-render when saving
			if (this.saving) return;

			const conditionsBlock = this.querySelector(".cq-study-signal-conditions");
			// Wipe the conditions block clean
			this.collapse(conditionsBlock);
			while (conditionsBlock.firstChild) conditionsBlock.lastChild.remove();

			// When adding a new study, all we need to do is clear out this block and wait for the active study to be set.
			if (!this.activeStudy) return;
			this.signalParams.studyName = this.activeStudy.name;
			if (!this.signalParams.conditions || !this.signalParams.conditions.length)
				this.signalParams.conditions = [[null, null, null, null]];

			this.signalParams.conditions.forEach((condition, idx) => {
				// Row container element
				const conditionRow = document.createElement("div");
				conditionRow.className = "cq-study-signal-condition";
				conditionsBlock.appendChild(conditionRow);

				// Field
				const lineValues = Object.keys(this.activeStudy.outputMap);
				if (!condition[0]) condition[0] = lineValues[0];

				let lineSelect = this.makeMenu(
					"ciq-condition-line",
					condition[0],
					lineValues,
					"SignalIQDialog.updateConditionVal(" + idx + ",0,$val)"
				);
				conditionRow.appendChild(lineSelect);

				// Operator
				if (condition[0]) {
					let opSelect = this.makeMenu(
						"ciq-condition-operator",
						condition[1],
						this.selectOptions.operator,
						"SignalIQDialog.updateConditionVal(" + idx + ",1,$val)"
					);
					conditionRow.appendChild(opSelect);
				}

				// Comparison
				if (condition[1] && condition[1].indexOf("p") < 0) {
					const comparisonContainer = document.createElement("div");
					comparisonContainer.className = "cq-comparison-container";
					conditionRow.appendChild(comparisonContainer);
					const comparisonOptions = Object.keys(
						this.activeStudy.outputMap
					).filter((item) => item != condition[0]);
					comparisonOptions.push("Value");
					if (!condition[2] && condition[2] !== 0)
						condition[2] = comparisonOptions[0];
					// Select comparison
					let comparisonSelect = this.makeMenu(
						"ciq-condition-comparison",
						condition[2],
						comparisonOptions,
						"SignalIQDialog.updateConditionVal(" + idx + ",2,$val)"
					);
					comparisonContainer.appendChild(comparisonSelect);

					// Value
					let valueInput = document.createElement("input");
					valueInput.className = "comparison";
					if (condition[2] || condition[2] === 0)
						valueInput.value = condition[2];
					if (
						!valueInput.value ||
						valueInput.value == "Value" ||
						!isNaN(valueInput.value)
					) {
						valueInput.type = "number";
						valueInput.step = "0.01";
						if (!valueInput.value) condition[2] = valueInput.value = 0;
					}
					valueInput.addEventListener("change", (event) =>
						this.updateConditionVal(null, idx, 2, event.target.value)
					);
					comparisonContainer.appendChild(valueInput);
				}

				// Color
				if (condition[1]) {
					let swatchContainer = document.createElement("span");
					swatchContainer.className = "ciq-condition-color";
					swatchContainer.setColor = (color) => {
						this.updateConditionVal(null, idx, 3, color == "auto" ? "" : color);
					};
					let swatch = document.createElement("cq-swatch");
					swatch.setAttribute("cq-overrides", "auto");
					swatchContainer.appendChild(swatch);
					conditionRow.appendChild(swatchContainer);
					swatch.setColor(condition[3] || "auto", false);
				}

				// Remove
				if (this.signalParams.conditions.length > 1) {
					let removeBtn = document.createElement("button");
					removeBtn.className = "ciq-btn ciq-condition-remove";
					removeBtn.innerText = "-";
					removeBtn.addEventListener("click", (event) => {
						event.preventDefault();
						this.signalParams.conditions.splice(idx, 1);
						this.renderConditionOptions();
					});
					conditionRow.appendChild(removeBtn);

					if (idx == 0) {
						// Add the joiner block
						let joinerGroup = document.createElement("div");
						joinerGroup.className = "joiner-group";

						let joinAnd = document.createElement("input");
						joinAnd.setAttribute("value", "&");
						joinAnd.setAttribute("type", "radio");
						joinAnd.setAttribute("name", "joiner");
						joinAnd.setAttribute("id", "joinand");
						joinAnd.addEventListener("change", (event) => {
							this.signalParams.joiner = event.target.value;
						});
						if (this.signalParams.joiner === "&")
							joinAnd.setAttribute("checked", "");
						joinerGroup.appendChild(joinAnd);
						let labelAnd = document.createElement("label");
						labelAnd.setAttribute("for", "joinand");
						labelAnd.innerText = "AND";
						joinerGroup.appendChild(labelAnd);
						let joinOr = document.createElement("input");
						joinOr.setAttribute("value", "|");
						joinOr.setAttribute("type", "radio");
						joinOr.setAttribute("name", "joiner");
						joinOr.setAttribute("id", "joinor");
						joinOr.addEventListener("change", (event) => {
							this.signalParams.joiner = event.target.value;
						});
						if (this.signalParams.joiner !== "&")
							joinOr.setAttribute("checked", "");
						joinerGroup.appendChild(joinOr);
						let labelOr = document.createElement("label");
						labelOr.setAttribute("for", "joinor");
						labelOr.innerText = "OR";
						joinerGroup.appendChild(labelOr);

						conditionsBlock.appendChild(joinerGroup);
					}
				}

				// Add
				if (
					idx == this.signalParams.conditions.length - 1 &&
					this.validateCondition(idx)
				) {
					let addBtn = document.createElement("div");
					addBtn.innerText = "+";
					addBtn.className = "ciq-btn ciq-condition-add";
					addBtn.addEventListener("click", () => {
						this.addCondition();
					});
					conditionRow.appendChild(addBtn);
				}
			});

			this.translate();
			this.validateSignalParams();
			this.renderMarkerPreview();
		}

		/**
		 * Update form controls related to marker options based on values in
		 * `signalParams`.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias renderMarkerOptions
		 * @since 8.6.0
		 */
		renderMarkerOptions() {
			const makeMarkerOptionMenu = (name, data) => {
				// Wipe the conditions block clean
				let ciqSelect = this.makeMenu(
					"marker-" + name,
					this.signalParams[name],
					data,
					"SignalIQDialog.updateParamValue('" + name + "',$val)"
				);
				return ciqSelect;
			};

			// Clear out the container
			let markerOptionsContainer = this.querySelector(".ciq-marker-options");
			this.collapse(markerOptionsContainer);
			while (markerOptionsContainer.firstChild)
				markerOptionsContainer.lastChild.remove();

			// Hide if notification Type is not "marker"
			let markerSettingsContainer = this.querySelector(".ciq-marker-container");
			if (this.signalParams.notificationType !== "marker") {
				markerSettingsContainer.classList.add("hide");
				return;
			}
			markerSettingsContainer.classList.remove("hide");

			// Add ciq-select menus
			markerOptionsContainer.appendChild(
				makeMarkerOptionMenu("shape", this.selectOptions.shape)
			);
			markerOptionsContainer.appendChild(
				makeMarkerOptionMenu("size", this.selectOptions.size)
			);

			let posLabel = document.createElement("label");
			posLabel.innerText = "Location";
			markerOptionsContainer.appendChild(posLabel);

			markerOptionsContainer.appendChild(
				makeMarkerOptionMenu("position", this.selectOptions.position)
			);

			let lblLabel = document.createElement("label");
			lblLabel.innerText = "Label";
			markerOptionsContainer.appendChild(lblLabel);

			let lblInput = document.createElement("input");
			lblInput.name = "marker-label";
			lblInput.type = "text";
			lblInput.value = this.signalParams.label || "";
			lblInput.addEventListener("change", (event) =>
				this.updateParamValue(null, "label", event.target.value)
			);
			markerOptionsContainer.appendChild(lblInput);

			this.renderMarkerPreview();
		}

		/**
		 * Update marker preview based on values in `signalParams`.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias renderMarkerPreview
		 * @since 8.6.0
		 */
		renderMarkerPreview() {
			const size = (sz) => {
				switch (sz) {
					case "L":
						return "large";
					case "M":
						return "medium";
					case "S":
					default:
						return "small";
				}
			};
			const marker = this.querySelector(".ciq-marker-preview .stx-marker");
			const visual = this.querySelector(".stx-visual");
			const content = this.querySelector(".stx-marker-content");

			marker.className =
				"stx-marker signal " +
				this.signalParams.shape +
				" " +
				size(this.signalParams.size);

			if (this.signalParams.conditions && this.signalParams.conditions[0]) {
				let bkgColor = this.signalParams.conditions[0][3];
				if (!bkgColor) {
					bkgColor =
						this.activeStudy.outputs[
							this.activeStudy.outputMap[this.signalParams.conditions[0][0]]
						];
					// Extract the color if the output is an object
					if (typeof bkgColor == "object" && bkgColor.color)
						bkgColor = bkgColor.color;
				}
				if (!bkgColor || bkgColor === "auto")
					bkgColor = this.context.stx.defaultColor;
				visual.style.backgroundColor = bkgColor;
				content.style.color = CIQ.chooseForegroundColor(bkgColor);
			}
			content.innerText = this.signalParams.label;

			this.translate();
		}

		/**
		 * Update notification types based on values in `signalParams`.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias renderNotificationTypes
		 * @since  8.6.0
		 */
		renderNotificationTypes() {
			// Display notificationType select box when there is more than one notification type
			const length = CIQ.SignalIQ.notificationTypes.length;
			if (length) {
				if (!this.signalParams.notificationType)
					this.updateParamValue(
						null,
						"notificationType",
						CIQ.SignalIQ.notificationTypes[0]
					);
				if (length > 1) {
					const notificationTypeBlock = this.querySelector(
						".notification-type-container"
					);
					// Wipe the conditions block clean
					this.collapse(notificationTypeBlock);
					while (notificationTypeBlock.firstChild)
						notificationTypeBlock.lastChild.remove();
					// Add a label
					let labelNotif = document.createElement("label");
					labelNotif.setAttribute("for", "notificationtype");
					labelNotif.innerText = "Notification Type:";
					notificationTypeBlock.appendChild(labelNotif);
					// Add the notification selection menu
					let notificationMenu = this.makeMenu(
						"notificationtype",
						this.signalParams.notificationType,
						CIQ.SignalIQ.notificationTypes,
						"SignalIQDialog.updateNotificationVal($val)"
					);
					notificationTypeBlock.appendChild(notificationMenu);
				}
			}
			this.translate();
		}

		/**
		 * Resets local study signal properties.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias reset
		 * @since 8.6.0
		 */
		reset() {
			if (this.stx) this.stx.removeEventListener(this.layoutListener);
			if (!this.editMode) this.removeActiveStudy();
			else this.activeStudy = null;
			this.signalParams = null;
		}

		/**
		 * Apply the current study signal settings to the active study and close the dialog.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias save
		 * @since 8.6.0
		 */
		save() {
			if (!this.activeStudy) return;

			this.updateFormValues(true);
			this.saving = true;
			if (
				this.stx.signalIQ.convertStudyToSignal(
					this.activeStudy,
					this.signalParams,
					this.editMode
				)
			) {
				this.editMode = true; // prevent deletion of newly added study
				this.close();
			}
			this.saving = false;
		}

		/**
		 * Translates a dialog.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias translate
		 * @since 8.6.0
		 */
		translate() {
			if (this.stx.translateUI) this.stx.translateUI(this);
		}

		/**
		 * Update a value in `signalParams.conditions` at provided index.
		 *
		 * @param {HTMLElement} node Element selected from the menu.
		 * @param {number} conditionIdx Index of the condition.
		 * @param {number} paramIdx Index of the property within the condition.
		 * @param {string|number} value Value for the condition property.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias updateConditionVal
		 * @since 8.6.0
		 */
		updateConditionVal(node, conditionIdx, paramIdx, value) {
			if (node && node.e) node.e.stopPropagation();
			this.signalParams.conditions[conditionIdx][paramIdx] = value;
			if (typeof value !== "number") this.renderConditionOptions();
		}

		/**
		 * Synchronizes dialog HTML elements in the local `formElements` property with
		 * values in the `signalParams` object. By default, this will update the
		 * element value with its corresponding `signalParams` value. Passing
		 * `formToData` parameter as `true` will update the corresponding
		 * `signalParams` value with the element value.
		 *
		 * @param {boolean} formToData Update `signalParams` with form values.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias updateFormValues
		 * @since 8.6.0
		 */
		updateFormValues(formToData) {
			Object.keys(this.formElements).forEach((key) => {
				if (formToData) {
					this.signalParams[key] = this.formElements[key].value;
				} else {
					this.formElements[key].value = this.signalParams[key];
				}
			});

			this.validateSignalParams();
			this.renderMarkerOptions();
		}

		/**
		 * Synchronizes notificationType dialog value with that in `signalParams` object.
		 *
		 * @param {HTMLElement} node Element selected from the menu.
		 * @param {string|number} value Value for the notification type.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias updateNotificationVal
		 * @since 8.6.0
		 */
		updateNotificationVal(node, value) {
			if (node && node.e) node.e.stopPropagation();
			this.signalParams.notificationType = value;
			this.renderNotificationTypes();
			this.renderMarkerOptions();
		}

		/**
		 * Update the value of a `signalParams` property.
		 *
		 * @param {HTMLElement} node Element selected from the menu.
		 * @param {string} name Name of the property.
		 * @param {string|number} value Value for the property.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias updateParamValue
		 * @since 8.6.0
		 */
		updateParamValue(node, name, value) {
			if (node && node.e) node.e.stopPropagation();
			this.signalParams[name] = value;
			this.validateSignalParams();
			this.renderMarkerOptions();
		}

		/**
		 * Checks local signalParams.conditions array for all properties required by
		 * {@link CIQ.SignalIQ#convertStudyToSignal}.
		 *
		 * @param {number} index Array index to check.
		 * @return {boolean} Return `true` if valid.
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias validateCondition
		 * @since 8.6.0
		 */
		validateCondition(index) {
			let condition = this.signalParams.conditions[index];
			if (!condition || !Array.isArray(condition) || condition.length < 3)
				return false;

			const nullIdx = condition.indexOf(null);
			if (
				nullIdx === 0 ||
				nullIdx === 1 ||
				(nullIdx === 2 && condition[1].indexOf("p") < 0)
			)
				return false;

			return true;
		}

		/**
		 * Checks local signalParams object for all properties required by
		 * {@link CIQ.SignalIQ#convertStudyToSignal}. Displays appropriate
		 * feedback messaging at bottom of dialog.
		 *
		 * @memberOf WebComponents.cq-signaliq-dialog#
		 * @alias validateSignalParams
		 * @since 8.6.0
		 */
		validateSignalParams() {
			let isValid = true;
			const warningElem = this.querySelector(".info-message");
			let warningMessage = "";
			let newName = this.formElements.name.value;

			if (!this.activeStudy) {
				isValid = false;
				warningMessage = "Select a study.";
			}

			if (!newName) {
				isValid = false;
			} else if (
				!this.editMode &&
				this.stx &&
				this.stx.layout &&
				this.stx.layout.studies
			) {
				// When adding a new study, check for an existing study signal with the same name
				if (
					Object.keys(this.stx.layout.studies).find((studyname) => {
						const sd = this.stx.layout.studies[studyname];
						if (sd.signalData && sd.signalData.name === newName) return true;
					})
				) {
					isValid = false;
					warningMessage = "Signals cannot have duplicate names.";
				}
			}

			if (this.signalParams)
				this.signalParams.conditions.forEach((condition, idx) => {
					if (!this.validateCondition(idx)) {
						isValid = false;
						warningMessage = "Define a signal action.";
					}
				});

			const saveBtn = this.querySelector(".ciq-btn-save");
			if (isValid) {
				saveBtn.classList.remove("ciq-btn-disabled");
			} else {
				saveBtn.classList.add("ciq-btn-disabled");
			}

			if (this.stx)
				warningElem.innerText = this.stx.translateIf(warningMessage);

			if (warningMessage) warningElem.classList.add("warning");
			else warningElem.classList.remove("warning");

			return isValid;
		}
	}

	SignalIQDialog.markup = `
		<h4 class="title">New Signal</h4>
		<cq-close></cq-close>
		<div cq-study-edit-dialog-div>
			<cq-scroll cq-no-maximize>
				<form id="study-signal" class="study-signal">
					<h2 cq-add-only>Choose a Study:</h2>
					<div class="study-select-container"></div>
					<div cq-tooltip-activator class="ciq-edit-study ciq-btn" stxtap="editStudy()">
						&nbsp;
						<cq-tooltip>Edit Study</cq-tooltip>
					</div>
					<h2>Define Conditions:</h2>
					<div class="cq-study-signal-conditions"></div>
					<hr/>
					<div class="notification-type-container"></div>
					<div class="ciq-marker-container">
						<h2>Choose an appearance:</h2>
						<div class="ciq-marker-settings">
							<div class="ciq-marker-preview">
								<div class="stx-marker signal">
									<div class="stx-visual"></div>
									<div class="stx-marker-content"></div>
								</div>
							</div>
							<div class="ciq-marker-options"></div>
						</div>
					</div>
					<h2>Description</h2>
					<textarea name="signal-description" type="text" placeholder="Description will appear in an infobox when the signal is clicked."></textarea>
					<hr/>
					<div class="clearfix"></div>
					<div class="ciq-misc-settings">
						<input name="signal-name" type="text" value="" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" placeholder="Enter a Name" />
						<div class="ciq-btn ciq-btn-save" stxtap="save()">Save</div>
						<h2 class="info-message"><h2>
					</div>
				</form>
			</cq-scroll>
			<template cq-study-menu>
				<cq-menu class="ciq-select">
					<cq-selected></cq-selected>
					<cq-menu-dropdown cq-lift>
						<cq-study-filter cq-filter-min="15"></cq-study-filter>
						<cq-study-items></cq-study-items>
					</cq-menu-dropdown>
				</cq-menu>
			</template>
			<template cq-menu>
				<cq-menu class="ciq-select">
					<cq-selected></cq-selected>
					<cq-menu-dropdown cq-lift></cq-menu-dropdown>
				</cq-menu>
			</template>
		</div>
	`;

	CIQ.UI.addComponentDefinition("cq-signaliq-dialog", SignalIQDialog);
}
