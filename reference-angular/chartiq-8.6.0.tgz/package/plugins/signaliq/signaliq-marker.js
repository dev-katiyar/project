/**
 *	8.6.0
 *	Generation date: 2022-03-28T16:28:54.145Z
 *	Client name: real investment advice
 *	Package Type: Technical Analysis e98f22c
 *	License type: annual
 *	Expiration date: "2022/08/19"
 *	Domain lock: ["127.0.0.1","localhost","realinvestmentadvice.com","riapro.net","18.188.218.82","simplevisor.com","3.138.80.45"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ } from "../../js/chartiq.js";
import "./signaliq.js";
import "./highPerformanceMarkers.js";

const cssReady = new Promise((resolve) => {
	if (
		typeof define === "undefined" &&
		typeof module === "object" &&
		typeof require === "function"
	) {
		// webpack 4
		resolve(require("./signaliq-marker.css"));
	} else if (typeof define === "function" && define.amd) {
		define(["./signaliq-marker.css"], resolve);
	} else if (import.meta.webpack) {
		// webpack 5
		import(/* webpackMode: "eager" */ "./signaliq-marker.css").then(resolve);
	} else if (typeof window !== "undefined") {
		// no webpack
		CIQ.SignalIQ.stylesheets.push({
			url: new URL("./signaliq-marker.css", import.meta.url).href,
			callback: resolve
		});
	}
}).then((m) => CIQ.addInternalStylesheet(m, "signaliq-marker")); // a framework, such as Angular, may require style addition

/**
 * Specific subclass of markers with a disabled placement function.
 *
 * @constructor
 * @name CIQ.Marker.SignalIQ
 * @private
 * @since 8.6.0
 */
CIQ.Marker.SignalIQ = function (params) {
	if (!this.className) this.className = "CIQ.Marker.SignalIQ";
	CIQ.Marker.call(this, params);
};

CIQ.inheritsFrom(CIQ.Marker.SignalIQ, CIQ.Marker, false);

CIQ.Marker.SignalIQ.placementFunction = () => {};

CIQ.SignalIQ.notificationTypes.push("marker");

/**
 * Namespace within CIQ.SignalIQ which represents an alert as a marker on the chart.
 *
 * @namespace CIQ.SignalIQ.Marker
 * @since  8.6.0
 */
CIQ.SignalIQ.Marker = {};

/**
 * Creates a signal as a marker. This is called when the `signalData.notificationType` value is "marker".
 *
 * @param {CIQ.SignalIQ~NotificationData} data Parameters used to create marker.
 * @return {CIQ.Marker.SignalIQ} A marker representing a SignalIQ alert.
 *
 * @static
 * @alias create
 * @memberof CIQ.SignalIQ.Marker
 * @since 8.6.0
 */
CIQ.SignalIQ.Marker.create = function ({
	signalData,
	color,
	conditions,
	field,
	isPlotSpecific,
	sd,
	stx,
	tick
}) {
	const size = (sz) => {
		switch (sz) {
			case "L":
				return "large";
			case "M":
				return "medium";
			case "S":
			default:
				return "small";
		}
	};
	const { name } = signalData;
	const yPositioner = isPlotSpecific
		? "on_candle"
		: signalData.position || "above_candle";
	const markerSignal = new CIQ.Marker.SignalIQ({
		stx,
		x: tick,
		xPositioner: "tick",
		yPositioner,
		offset: !isPlotSpecific && yPositioner.includes("candle") ? 8 : 0,
		label: "signaliq-" + name,
		panelName: isPlotSpecific ? sd.panel : undefined,
		field,
		avoidFlush: true,
		node: isPlotSpecific
			? new CIQ.Marker.Performance({
					type: "circle",
					category: "signal",
					size: "study",
					displayCategory: false,
					displayStem: false,
					id: name,
					headline: name,
					story:
						(stx.signalIQ.displayCondition
							? "\u000a" + conditions.join("\u000a")
							: "") +
						(signalData.description ? "\u000a" + signalData.description : ""),
					hide: !signalData.reveal,
					color
			  })
			: new CIQ.Marker.Performance({
					type: signalData.shape || "circle",
					category: "signal",
					size: size(signalData.size),
					displayLabel: signalData.label,
					displayCategory: false,
					displayStem: false,
					id: name,
					color
			  })
	});
	if (!isPlotSpecific)
		markerSignal.click = (function (stx, sd) {
			return function () {
				stx.signalIQ[sd.signalData.reveal ? "hide" : "show"](sd);
				stx.findHighlights(null, true);
			};
		})(stx, sd);

	markerSignal.uniqueKey = [
		markerSignal.node.params.id,
		markerSignal.tick,
		markerSignal.params.field
	].join("|");

	return markerSignal;
};
